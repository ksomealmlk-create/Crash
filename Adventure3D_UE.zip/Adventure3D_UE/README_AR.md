# Adventure 3D – نسخة Unreal Engine 5.4 (C++)

اللعبة نفسها (نفس المستوى، الأعداء، الصناديق، نقاط الحفظ، الليزر، المنصة المتحركة، الفوز/الخسارة)
لكن بمحرك Unreal وكود C++. كل شي ينبني من الكود، ما تحتاج تفتح المحرر وتحط شي بالايد.

## تحذير مهم (اقرأه)
1. **الكود ما انكتب/انجرّب على Unreal فعلياً** (ما عندي المحرك). ممكن يطلع خطأ كومبايل صغير بأول مرة.
   إذا طلع: انسخ سطور الخطأ وابعثها لي وأصلحها.
2. **سيرفرات GitHub المجانية ما تقدر تبني Unreal** (المحرك أكثر من 100 GB والسيرفر عنده ~14 GB).
   لذلك الـ workflow مضبوط على **Self-hosted runner** = جهازك أنت (Windows + UE 5.4).
   إذا ما عندك PC، الخيار الأسهل تبقى على نسخة Godot لأن بنائها على GitHub المجاني شغّال.

## المتطلبات (على الـ PC)
- Unreal Engine 5.4 (من Epic Launcher) + Android: Android Studio Flamingo (2022.2.1 patch 2)، SDK 34، NDK 25.1.8937393، JDK 17
  (المحرر: Platforms > Android > SDK Setup يسويها لك).
- مساحة ~100 GB، رام 16 GB.

## بناء الـ APK (الطريقة الأسهل: بدون GitHub)
1. فك الـ zip، افتح CMD بنفس المجلد.
2. شغّل: `Build_Android.bat`  (إذا المحرك مو بالمسار الافتراضي: `set UE_ROOT=D:\UE_5.4` قبلها)
3. الـ APK يطلع بـ `Build\Android_ASTC\`.

## بناء الـ APK من GitHub
1. ارفع المشروع لـ repo.
2. Settings > Actions > Runners > New self-hosted runner (Windows) وسوّي الخطوات على جهازك.
3. Actions > "Build Android APK (Unreal)" > Run workflow. الـ APK يطلع بالـ Artifacts.

## موديلاتك (hero.glb / enemy / crate / flag) – اختياري
بدونها اللعبة تشتغل بأشكال مدمجة (بطل متحرك من أشكال + عدو بنفسجي + صندوق خشب).
لاستخدام موديلاتك:
1. Blender: `blender -b --python Tools/glb_to_fbx.py -- ImportSource ImportSource/FBX`
2. شغّل `Build_Android.bat` (يسوي مواد + يستورد الـ FBX تلقائياً).
3. البطل المدمج عنده أنيميشن كامل. موديل hero.glb ينعرض بدون تحريك أطراف، فخليته مطفّي:
   لتشغيله غيّر `bUseImportedHero=True` بـ `Config/DefaultGame.ini`.

## إضافات الرسوميات
قمر ونجوم، ضباب، Bloom + Vignette + ألوان سينمائية، ظلال ديناميكية من القمر، يراعات،
شعلات بإضاءة متذبذبة، حواف منصات مضيئة، ليزر نابض، جزيئات، اهتزاز كاميرا وفلاش أحمر عند الإصابة،
زر HD/LD يشغّل/يطفّي الظلال والـ Bloom. (Lumen/Nanite/Ray Tracing مو مدعومة على الموبايل.)

## إذا الصورة غامقة أو مفتوحة زيادة
عدّل `Config/DefaultGame.ini` (قسم `Adventure3D.AdvGameMode`): `ExposureEV` (جرّب 1.0 – 4.0)، `BloomIntensity`، `FogDensity`.

## التحكم
موبايل: النص الأيسر = عصا حركة عائمة، الوسط-يمين = SPIN، أقصى اليمين = JUMP.
كمبيوتر: WASD/أسهم، Space = قفز، E أو Shift = دوران، Esc/P = إيقاف.

## الملفات
`Source/Adventure3D/` كل الكود (AdvGameMode = منطق اللعبة، AdvCharacter = البطل، AdvActors = العناصر).
`Tools/SetupAssets.py` مواد + استيراد، `Tools/glb_to_fbx.py` تحويل بـ Blender.
ملاحظة: شخصيتي Judy و Lion كانت موجودة بالمشروع بس مو مستخدمة بالـ gameplay، فما نقلتها.
