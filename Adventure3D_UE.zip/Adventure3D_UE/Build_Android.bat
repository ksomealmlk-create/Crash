@echo off
setlocal
REM Builds Adventure3D.apk with Unreal Engine 5.4 (Windows).
REM Set UE_ROOT if your engine is not in the default folder.
if "%UE_ROOT%"=="" set "UE_ROOT=C:\Program Files\Epic Games\UE_5.4"
set "PROJ=%~dp0Adventure3D.uproject"
set "OUT=%~dp0Build"

echo [1/3] Compiling editor target...
call "%UE_ROOT%\Engine\Build\BatchFiles\Build.bat" Adventure3DEditor Win64 Development -Project="%PROJ%" -WaitMutex
if errorlevel 1 exit /b 1

echo [2/3] Creating materials / importing models (optional, failures are not fatal)...
"%UE_ROOT%\Engine\Binaries\Win64\UnrealEditor-Cmd.exe" "%PROJ%" -run=pythonscript -script="%~dp0Tools\SetupAssets.py" -unattended -nop4 -nosplash -stdout

echo [3/3] Cook + package Android APK...
call "%UE_ROOT%\Engine\Build\BatchFiles\RunUAT.bat" BuildCookRun -project="%PROJ%" -noP4 -platform=Android -cookflavor=ASTC -clientconfig=Development -build -cook -stage -pak -package -archive -archivedirectory="%OUT%" -utf8output -unattended -nosplash
if errorlevel 1 exit /b 1

echo.
echo Done. APK is under: %OUT%\Android_ASTC\
