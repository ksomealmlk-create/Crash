"""
Run INSIDE Unreal (headless is fine). Creates:
  /Game/Materials/M_Adv_Lit          lit color + moonlit ambient term
  /Game/Materials/M_Adv_Glow         unlit emissive (fire, moon, stars, edge lights ...)
  /Game/Materials/M_Adv_VertexColor  for hero.glb (its colors live in the vertices)
and imports every FBX found in ImportSource/FBX into /Game/Models/<Name>.

The game works without this step (it falls back to built-in shapes), this just makes it prettier.
Command line:  UnrealEditor-Cmd <uproject> -run=pythonscript -script=Tools/SetupAssets.py
"""
import os
import unreal

tools = unreal.AssetToolsHelpers.get_asset_tools()
mel = unreal.MaterialEditingLibrary
eal = unreal.EditorAssetLibrary
PROJECT = unreal.Paths.project_dir()


def log(msg):
    unreal.log("[Adv] " + str(msg))


def new_material(name):
    path = "/Game/Materials/" + name
    if eal.does_asset_exist(path):
        eal.delete_asset(path)
    mat = tools.create_asset(name, "/Game/Materials", unreal.Material, unreal.MaterialFactoryNew())
    for flag in ("used_with_instanced_static_meshes", "used_with_skeletal_mesh", "used_with_static_lighting"):
        try:
            mat.set_editor_property(flag, flag != "used_with_static_lighting")
        except Exception as e:  # property names differ a bit between versions
            log("flag %s skipped: %s" % (flag, e))
    return mat


def expr(mat, cls, x, y):
    return mel.create_material_expression(mat, cls, x, y)


def vec_param(mat, name, default, x, y):
    e = expr(mat, unreal.MaterialExpressionVectorParameter, x, y)
    e.set_editor_property("parameter_name", name)
    e.set_editor_property("default_value", unreal.LinearColor(*default))
    return e


def scalar_param(mat, name, default, x, y):
    e = expr(mat, unreal.MaterialExpressionScalarParameter, x, y)
    e.set_editor_property("parameter_name", name)
    e.set_editor_property("default_value", default)
    return e


def mul(mat, a, b, x, y):
    m = expr(mat, unreal.MaterialExpressionMultiply, x, y)
    mel.connect_material_expressions(a, "", m, "A")
    mel.connect_material_expressions(b, "", m, "B")
    return m


def finish(mat):
    mel.recompile_material(mat)
    eal.save_asset(mat.get_path_name())
    log("saved " + mat.get_path_name())


def make_lit():
    m = new_material("M_Adv_Lit")
    color = vec_param(m, "Color", (0.5, 0.5, 0.5, 1.0), -900, -300)
    rough = scalar_param(m, "Roughness", 0.85, -900, -100)
    amb = vec_param(m, "AmbientTint", (0.045, 0.073, 0.213, 1.0), -900, 100)
    boost = scalar_param(m, "AmbientBoost", 4.8, -900, 300)
    ambient = mul(m, mul(m, color, amb, -600, 0), boost, -350, 100)
    mel.connect_material_property(color, "", unreal.MaterialProperty.MP_BASE_COLOR)
    mel.connect_material_property(rough, "", unreal.MaterialProperty.MP_ROUGHNESS)
    mel.connect_material_property(ambient, "", unreal.MaterialProperty.MP_EMISSIVE_COLOR)
    finish(m)


def make_glow():
    m = new_material("M_Adv_Glow")
    try:
        m.set_editor_property("shading_model", unreal.MaterialShadingModel.MSM_UNLIT)
    except Exception as e:
        log("unlit not set: %s" % e)
    color = vec_param(m, "Color", (1.0, 1.0, 1.0, 1.0), -700, 0)
    inten = scalar_param(m, "Intensity", 4.8, -700, 200)
    emis = mul(m, color, inten, -400, 100)
    mel.connect_material_property(emis, "", unreal.MaterialProperty.MP_EMISSIVE_COLOR)
    finish(m)


def make_vertex_color():
    m = new_material("M_Adv_VertexColor")
    vc = expr(m, unreal.MaterialExpressionVertexColor, -900, 0)
    amb = vec_param(m, "AmbientTint", (0.045, 0.073, 0.213, 1.0), -900, 200)
    boost = scalar_param(m, "AmbientBoost", 4.8, -900, 400)
    rough = scalar_param(m, "Roughness", 0.7, -900, -200)
    ambient = mul(m, mul(m, vc, amb, -600, 100), boost, -350, 100)
    mel.connect_material_property(vc, "", unreal.MaterialProperty.MP_BASE_COLOR)
    mel.connect_material_property(rough, "", unreal.MaterialProperty.MP_ROUGHNESS)
    mel.connect_material_property(ambient, "", unreal.MaterialProperty.MP_EMISSIVE_COLOR)
    finish(m)


NAMES = {"hero": "Hero", "crate": "Crate", "enemy": "Enemy", "goal_flag": "Flag"}


def import_fbx(path, name):
    task = unreal.AssetImportTask()
    task.set_editor_property("filename", path)
    task.set_editor_property("destination_path", "/Game/Models/" + name)
    task.set_editor_property("destination_name", name)
    task.set_editor_property("automated", True)
    task.set_editor_property("save", True)
    task.set_editor_property("replace_existing", True)
    opts = unreal.FbxImportUI()
    opts.set_editor_property("import_mesh", True)
    opts.set_editor_property("import_materials", True)
    opts.set_editor_property("import_textures", True)
    opts.set_editor_property("import_animations", True)
    task.set_editor_property("options", opts)
    tools.import_asset_tasks([task])
    log("imported %s -> /Game/Models/%s" % (os.path.basename(path), name))


def main():
    for fn in (make_lit, make_glow, make_vertex_color):
        try:
            fn()
        except Exception as e:
            log("MATERIAL STEP FAILED (%s): %s" % (fn.__name__, e))

    fbx_dir = os.path.join(PROJECT, "ImportSource", "FBX")
    if not os.path.isdir(fbx_dir):
        log("no ImportSource/FBX folder - run Tools/glb_to_fbx.py with Blender first to import your models")
        return
    for f in sorted(os.listdir(fbx_dir)):
        stem, ext = os.path.splitext(f)
        if ext.lower() == ".fbx" and stem in NAMES:
            try:
                import_fbx(os.path.join(fbx_dir, f), NAMES[stem])
            except Exception as e:
                log("IMPORT FAILED %s: %s" % (f, e))


main()
