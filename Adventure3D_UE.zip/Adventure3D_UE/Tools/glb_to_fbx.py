"""
Converts the Godot models (glb/gltf) to FBX so Unreal can import them reliably.
Usage (Blender 3.6+ / 4.x):
  blender -b --python Tools/glb_to_fbx.py -- ImportSource ImportSource/FBX
"""
import glob
import os
import sys

import bpy

args = sys.argv[sys.argv.index("--") + 1:]
src, dst = args[0], args[1]
os.makedirs(dst, exist_ok=True)

files = sorted(glob.glob(os.path.join(src, "*.glb")) + glob.glob(os.path.join(src, "*.gltf")))
for f in files:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=f)
    out = os.path.join(dst, os.path.splitext(os.path.basename(f))[0] + ".fbx")
    bpy.ops.export_scene.fbx(
        filepath=out,
        use_selection=False,
        object_types={"ARMATURE", "MESH"},
        apply_scale_options="FBX_SCALE_UNITS",
        add_leaf_bones=False,
        bake_anim=True,
        path_mode="COPY",
        embed_textures=True,
    )
    print("converted", f, "->", out)
