#!/usr/bin/env bash
# Linux version of Build_Android.bat. Needs UE 5.4 for Linux + Android SDK/NDK set up (Engine/Extras/Android/SetupAndroid.sh).
set -e
UE_ROOT="${UE_ROOT:-$HOME/UnrealEngine/UE_5.4}"
HERE="$(cd "$(dirname "$0")" && pwd)"
PROJ="$HERE/Adventure3D.uproject"

"$UE_ROOT/Engine/Build/BatchFiles/Linux/Build.sh" Adventure3DEditor Linux Development -Project="$PROJ" -WaitMutex
"$UE_ROOT/Engine/Binaries/Linux/UnrealEditor-Cmd" "$PROJ" -run=pythonscript -script="$HERE/Tools/SetupAssets.py" -unattended -nop4 -nosplash -stdout || true
"$UE_ROOT/Engine/Build/BatchFiles/RunUAT.sh" BuildCookRun -project="$PROJ" -noP4 -platform=Android -cookflavor=ASTC \
  -clientconfig=Development -build -cook -stage -pak -package -archive -archivedirectory="$HERE/Build" -utf8output -unattended -nosplash
echo "APK is under $HERE/Build/Android_ASTC/"
