using UnrealBuildTool;
using System.Collections.Generic;

public class Adventure3DEditorTarget : TargetRules
{
	public Adventure3DEditorTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Editor;
		DefaultBuildSettings = BuildSettingsVersion.Latest;
		IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
		ExtraModuleNames.Add("Adventure3D");
	}
}
