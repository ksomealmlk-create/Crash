#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "AdvAssets.generated.h"

class UStaticMesh;
class UMaterialInterface;
class UMaterialInstanceDynamic;
class UStaticMeshComponent;
class UBoxComponent;
class USceneComponent;
class AActor;

/**
 * Holds the engine meshes/materials and small helpers to build props out of primitives.
 * Everything falls back to Unreal's built-in shapes, so the game works even if no custom
 * assets were imported (Tools/SetupAssets.py adds nicer materials + your models).
 */
UCLASS()
class ADVENTURE3D_API UAdvAssets : public UObject
{
	GENERATED_BODY()

public:
	UAdvAssets();

	UPROPERTY() TObjectPtr<UStaticMesh> Cube;
	UPROPERTY() TObjectPtr<UStaticMesh> Sphere;
	UPROPERTY() TObjectPtr<UStaticMesh> Cylinder;
	UPROPERTY() TObjectPtr<UStaticMesh> Cone;
	UPROPERTY() TObjectPtr<UMaterialInterface> LitBase;
	UPROPERTY() TObjectPtr<UMaterialInterface> GlowBase;
	UPROPERTY() TObjectPtr<UMaterialInterface> VertexColorBase;

	bool bCustomLit = false;
	bool bCustomGlow = false;
	float ExposureComp = 4.8f; // 1.2 * 2^EV  (converts "pixel value" to scene luminance)

	// Colors passed in are Godot-style sRGB values.
	UMaterialInstanceDynamic* Lit(UObject* Outer, const FLinearColor& Srgb, float Roughness = 0.85f) const;
	UMaterialInstanceDynamic* Glow(UObject* Outer, const FLinearColor& Srgb, float Energy) const;
	void SetGlow(UMaterialInstanceDynamic* M, const FLinearColor& Srgb, float Energy) const;

	// ---- component builders (all sizes in cm, locations relative to Parent) ----
	USceneComponent* Pivot(AActor* Owner, USceneComponent* Parent, const FVector& Loc) const;
	UStaticMeshComponent* Part(AActor* Owner, USceneComponent* Parent, UStaticMesh* Mesh, UMaterialInterface* Mat,
		const FVector& Loc, const FVector& Scale, const FRotator& Rot = FRotator::ZeroRotator, bool bShadow = true) const;
	UBoxComponent* Collider(AActor* Owner, USceneComponent* Parent, const FVector& Loc, const FVector& FullSize) const;
	UStaticMeshComponent* Box(AActor* Owner, USceneComponent* Parent, UMaterialInterface* Mat, const FVector& Loc,
		const FVector& SizeCm, const FRotator& Rot = FRotator::ZeroRotator, bool bShadow = true) const;
	UStaticMeshComponent* Ball(AActor* Owner, USceneComponent* Parent, UMaterialInterface* Mat, const FVector& Loc,
		float RadiusCm, const FVector& Squash = FVector::OneVector, bool bShadow = true) const;
	UStaticMeshComponent* Tube(AActor* Owner, USceneComponent* Parent, UMaterialInterface* Mat, const FVector& Loc,
		float RadiusCm, float LengthCm, const FRotator& Rot = FRotator::ZeroRotator, bool bShadow = true) const;
	UStaticMeshComponent* Spike(AActor* Owner, USceneComponent* Parent, UMaterialInterface* Mat, const FVector& Loc,
		float RadiusCm, float HeightCm, const FRotator& Rot = FRotator::ZeroRotator, bool bShadow = true) const;

	// Platform = collider + body + highlight + underside + pillars + glowing edge strips.
	// C is the body center (relative to Parent), W/Ln are Godot width/length in meters, Top is the Godot top height.
	void Platform(AActor* Owner, USceneComponent* Parent, const FVector& C, float W, float Ln, float Top,
		const FLinearColor& Srgb) const;

	// ---- imported models (optional, from Tools/SetupAssets.py) ----
	static UObject* FindImported(const FString& Folder, UClass* Class);
	// Returns the new component or nullptr when nothing was imported. Scaled so the largest side = TargetCm.
	USceneComponent* ImportedModel(AActor* Owner, USceneComponent* Parent, const FString& Folder, float TargetCm,
		const FVector& Loc, UMaterialInterface* MatOverride = nullptr) const;
};
