#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "AdvCommon.h"
#include "AdvGameMode.generated.h"

class UAdvAssets;
class AAdvCharacter;
class AAdvCrate;
class AAdvEnemy;
class AAdvCheckpoint;
class AAdvMover;
class AAdvFireflies;
class AAdvLevelActor;
class ADirectionalLight;
class APostProcessVolume;
class USoundWaveProcedural;
class UMaterialInstanceDynamic;

/** Game rules (ported from main.gd): level, enemies, crates, checkpoints, win/lose, UI state. */
UCLASS(Config = Game)
class ADVENTURE3D_API AAdvGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	AAdvGameMode();
	virtual void InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage) override;
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	// ---- tuning (Config/DefaultGame.ini) ----
	UPROPERTY(Config) float ExposureEV = 2.0f;
	UPROPERTY(Config) float BloomIntensity = 1.2f;
	UPROPERTY(Config) float FogDensity = 0.006f;
	UPROPERTY(Config) bool bUseImportedHero = false;
	UPROPERTY(Config) bool bUseImportedModels = true;

	UPROPERTY() TObjectPtr<UAdvAssets> Assets;

	// ---- state read by HUD / controller ----
	EAdvState State = EAdvState::Menu;
	int32 Fruits = 0;
	int32 Lives = 3;
	bool bFxOn = true;
	float HurtFlash = 0.f;
	FString PanelTitle;
	FString PanelButton;

	void OnMainButton();
	void OnPause();
	void OnQuality();

	void PlaySfx(EAdvSfx Sfx);
	void Burst(const FVector& Pos, const FLinearColor& Srgb, int32 Amount, float SpeedCm);

private:
	void BuildEnvironment();
	void BuildForest();
	void BuildSounds();
	void BuildLevel();
	void ResetGame();
	void ShowPanel(const FString& Title, const FString& Button);
	void Hurt();
	bool Near(const FVector& A, const FVector& B, float R) const;

	// level helpers
	void Plat(float Cx, float Top, float Z0, float Z1, float W, const FLinearColor& Col);
	void SpawnCrate(float X, float Y, float Z);
	void SpawnEnemy(float X, float Y, float Z, float Range, bool bAxisX);
	void SpawnTorch(float X, float Y, float Z);
	void SpawnCheckpoint(const FVector& Spot, const FVector& FlagPos);
	void SpawnHazard(const FVector& GodotPos);
	void SpawnBridge(float Z0, float Z1, float Top, float Half);
	void SpawnArch(float Z, float Top, float Half);
	void SpawnGoal();

	UPROPERTY() TObjectPtr<AAdvCharacter> Player;
	UPROPERTY() TObjectPtr<AAdvLevelActor> Level;
	UPROPERTY() TObjectPtr<AAdvFireflies> Fireflies;
	UPROPERTY() TObjectPtr<ADirectionalLight> Sun;
	UPROPERTY() TObjectPtr<APostProcessVolume> Post;

	UPROPERTY() TArray<TObjectPtr<AActor>> Spawned;
	UPROPERTY() TArray<TObjectPtr<AAdvCrate>> Crates;
	UPROPERTY() TArray<TObjectPtr<AAdvEnemy>> Enemies;
	UPROPERTY() TArray<TObjectPtr<AAdvCheckpoint>> Checkpoints;
	UPROPERTY() TArray<TObjectPtr<AAdvMover>> Movers;
	UPROPERTY() TArray<TObjectPtr<UMaterialInstanceDynamic>> HazardMats;
	UPROPERTY() TArray<TObjectPtr<USoundWaveProcedural>> SfxKeep;

	struct FHazard { FVector Pos; FVector Half; };
	TArray<FHazard> Hazards;

	TArray<TArray<uint8>> SfxData;
	TArray<float> SfxDur;

	FVector StartPos = FVector::ZeroVector;
	FVector RespawnPos = FVector::ZeroVector;
	float T = 0.f;
	float SpinSparkT = 0.f;
	bool bWon = false;
};
