#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "AdvActors.generated.h"

class UAdvAssets;
class UMaterialInstanceDynamic;
class UPointLightComponent;
class UInstancedStaticMeshComponent;
class USceneComponent;

/** Empty holder for all the static level geometry. */
UCLASS()
class ADVENTURE3D_API AAdvLevelActor : public AActor
{
	GENERATED_BODY()
public:
	AAdvLevelActor();
};

/** Wooden crate: solid, destroyed by the spin attack (gives a "fruit"). */
UCLASS()
class ADVENTURE3D_API AAdvCrate : public AActor
{
	GENERATED_BODY()
public:
	AAdvCrate();
	void Setup(UAdvAssets* Assets, bool bUseImported);
};

/** Purple blob enemy that patrols along one axis. Movement is driven by the game mode. */
UCLASS()
class ADVENTURE3D_API AAdvEnemy : public AActor
{
	GENERATED_BODY()
public:
	AAdvEnemy();
	virtual void Tick(float DeltaSeconds) override;
	void Setup(UAdvAssets* Assets, bool bUseImported);

	FVector Center = FVector::ZeroVector;
	float Range = 300.f;
	bool bAxisX = true; // Godot "x" axis == Unreal Y

private:
	UPROPERTY() TObjectPtr<USceneComponent> BodyPivot;
	float Age = 0.f;
};

UCLASS()
class ADVENTURE3D_API AAdvCheckpoint : public AActor
{
	GENERATED_BODY()
public:
	AAdvCheckpoint();
	void Setup(UAdvAssets* Assets);
	void Activate();

	FVector Spot = FVector::ZeroVector; // detection point
	bool bDone = false;

private:
	UPROPERTY() TObjectPtr<UMaterialInstanceDynamic> Cloth;
	UPROPERTY() TObjectPtr<UAdvAssets> Bank;
};

/** Torch with flickering flame + warm light. */
UCLASS()
class ADVENTURE3D_API AAdvTorch : public AActor
{
	GENERATED_BODY()
public:
	AAdvTorch();
	virtual void Tick(float DeltaSeconds) override;
	void Setup(UAdvAssets* Assets);

private:
	UPROPERTY() TObjectPtr<UPointLightComponent> Light;
	UPROPERTY() TObjectPtr<USceneComponent> Flame;
	float BaseCd = 100.f;
	float Phase = 0.f;
	float Age = 0.f;
};

/** The blue moving platform. */
UCLASS()
class ADVENTURE3D_API AAdvMover : public AActor
{
	GENERATED_BODY()
public:
	AAdvMover();
	void Setup(UAdvAssets* Assets, float W, float Ln, float Top, const FLinearColor& Srgb);

	FVector Base = FVector::ZeroVector;
	float Amp = 200.f;
};

/** One-shot burst of glowing cubes (replaces Godot's CPUParticles3D). */
UCLASS()
class ADVENTURE3D_API AAdvBurst : public AActor
{
	GENERATED_BODY()
public:
	AAdvBurst();
	virtual void Tick(float DeltaSeconds) override;
	void Init(UAdvAssets* Assets, const FLinearColor& Srgb, int32 Amount, float SpeedCm);

private:
	UPROPERTY() TObjectPtr<UInstancedStaticMeshComponent> Ism;
	TArray<FVector> Pos;
	TArray<FVector> Vel;
	float Age = 0.f;
	float Life = 0.5f;
};

/** Fireflies drifting around the camera. */
UCLASS()
class ADVENTURE3D_API AAdvFireflies : public AActor
{
	GENERATED_BODY()
public:
	AAdvFireflies();
	virtual void Tick(float DeltaSeconds) override;
	void Setup(UAdvAssets* Assets);

private:
	UPROPERTY() TObjectPtr<UInstancedStaticMeshComponent> Ism;
	TArray<FVector> Off;
	TArray<FVector> Vel;
	TArray<float> Ph;
	float Age = 0.f;
};

/** Moon + stars, glued to the camera so they sit "at infinity". */
UCLASS()
class ADVENTURE3D_API AAdvSky : public AActor
{
	GENERATED_BODY()
public:
	AAdvSky();
	virtual void Tick(float DeltaSeconds) override;
	void Setup(UAdvAssets* Assets);
};
