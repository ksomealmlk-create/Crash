#include "AdvActors.h"
#include "AdvAssets.h"
#include "AdvCommon.h"
#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/PointLightComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Camera/PlayerCameraManager.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"

static USceneComponent* MakeRoot(AActor* A)
{
	USceneComponent* R = A->CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	R->SetMobility(EComponentMobility::Movable);
	A->SetRootComponent(R);
	return R;
}

// ---------------------------------------------------------------- level holder
AAdvLevelActor::AAdvLevelActor()
{
	PrimaryActorTick.bCanEverTick = false;
	MakeRoot(this);
}

// ---------------------------------------------------------------- crate
AAdvCrate::AAdvCrate()
{
	PrimaryActorTick.bCanEverTick = false;
	MakeRoot(this);
}

void AAdvCrate::Setup(UAdvAssets* A, bool bUseImported)
{
	USceneComponent* R = GetRootComponent();
	A->Collider(this, R, FVector::ZeroVector, FVector(100.f));

	if (bUseImported && A->ImportedModel(this, R, TEXT("Crate"), 100.f, FVector::ZeroVector))
	{
		return;
	}

	UMaterialInstanceDynamic* Wood = A->Lit(this, FLinearColor(0.5f, 0.34f, 0.2f));
	UMaterialInstanceDynamic* Dark = A->Lit(this, FLinearColor(0.22f, 0.14f, 0.08f));
	A->Box(this, R, Wood, FVector::ZeroVector, FVector(100.f));
	for (int32 sx = -1; sx <= 1; sx += 2)
	{
		for (int32 sz = -1; sz <= 1; sz += 2)
		{
			A->Box(this, R, Dark, FVector(-sz * 50.f, sx * 50.f, 0.f), FVector(14.f, 14.f, 104.f));
		}
	}
	// X-braces on the side facing the camera (-X)
	A->Box(this, R, Dark, FVector(-51.f, 0.f, 0.f), FVector(4.f, 125.f, 10.f), FRotator(0.f, 0.f, 45.f));
	A->Box(this, R, Dark, FVector(-51.f, 0.f, 0.f), FVector(4.f, 125.f, 10.f), FRotator(0.f, 0.f, -45.f));
}

// ---------------------------------------------------------------- enemy
AAdvEnemy::AAdvEnemy()
{
	PrimaryActorTick.bCanEverTick = true;
	MakeRoot(this);
}

void AAdvEnemy::Setup(UAdvAssets* A, bool bUseImported)
{
	USceneComponent* R = GetRootComponent();
	BodyPivot = A->Pivot(this, R, FVector::ZeroVector);

	if (bUseImported && A->ImportedModel(this, BodyPivot, TEXT("Enemy"), 100.f, FVector(0.f, 0.f, -40.f)))
	{
		return;
	}

	const FLinearColor Purple(0.45f, 0.12f, 0.55f);
	UMaterialInstanceDynamic* Body = A->Lit(this, Purple);
	UMaterialInstanceDynamic* EyeG = A->Glow(this, FLinearColor(0.8f, 1.f, 0.3f), 3.f);
	UMaterialInstanceDynamic* Black = A->Lit(this, FLinearColor(0.f, 0.f, 0.f));
	UMaterialInstanceDynamic* Feet = A->Lit(this, FLinearColor(0.15f, 0.03f, 0.2f));
	UMaterialInstanceDynamic* Brow = A->Lit(this, FLinearColor(0.1f, 0.f, 0.15f));

	A->Ball(this, BodyPivot, Body, FVector::ZeroVector, 45.f, FVector(1.f, 1.f, 0.9f));
	// face looks toward the camera (-X)
	A->Ball(this, BodyPivot, EyeG, FVector(-34.f, -17.f, 12.f), 14.f, FVector::OneVector, false);
	A->Ball(this, BodyPivot, EyeG, FVector(-34.f, 17.f, 12.f), 14.f, FVector::OneVector, false);
	A->Ball(this, BodyPivot, Black, FVector(-46.f, -17.f, 12.f), 6.f, FVector::OneVector, false);
	A->Ball(this, BodyPivot, Black, FVector(-46.f, 17.f, 12.f), 6.f, FVector::OneVector, false);
	A->Ball(this, BodyPivot, Feet, FVector(-10.f, -20.f, -40.f), 10.f, FVector(1.3f, 1.f, 0.6f));
	A->Ball(this, BodyPivot, Feet, FVector(-10.f, 20.f, -40.f), 10.f, FVector(1.3f, 1.f, 0.6f));
	A->Box(this, BodyPivot, Brow, FVector(-40.f, -17.f, 32.f), FVector(5.f, 24.f, 5.f), FRotator(0.f, 0.f, 28.f), false);
	A->Box(this, BodyPivot, Brow, FVector(-40.f, 17.f, 32.f), FVector(5.f, 24.f, 5.f), FRotator(0.f, 0.f, -28.f), false);
}

void AAdvEnemy::Tick(float Dt)
{
	Super::Tick(Dt);
	Age += Dt;
	if (BodyPivot)
	{
		// little squash & stretch so they feel alive
		const float S = FMath::Sin(Age * 6.f);
		BodyPivot->SetRelativeScale3D(FVector(1.f - 0.04f * S, 1.f - 0.04f * S, 1.f + 0.07f * S));
	}
}

// ---------------------------------------------------------------- checkpoint
AAdvCheckpoint::AAdvCheckpoint()
{
	PrimaryActorTick.bCanEverTick = false;
	MakeRoot(this);
}

void AAdvCheckpoint::Setup(UAdvAssets* A)
{
	Bank = A;
	USceneComponent* R = GetRootComponent();
	UMaterialInstanceDynamic* Pole = A->Lit(this, FLinearColor(0.6f, 0.6f, 0.65f));
	UMaterialInstanceDynamic* Foot = A->Lit(this, FLinearColor(0.3f, 0.3f, 0.35f));
	A->Box(this, R, Pole, FVector::ZeroVector, FVector(12.f, 12.f, 220.f));
	A->Box(this, R, Foot, FVector(0.f, 0.f, -110.f), FVector(60.f, 60.f, 15.f));
	Cloth = A->Glow(this, FLinearColor(0.8f, 0.1f, 0.1f), 1.5f);
	A->Box(this, R, Cloth, FVector(0.f, 40.f, 80.f), FVector(5.f, 70.f, 45.f), FRotator::ZeroRotator, false);
}

void AAdvCheckpoint::Activate()
{
	bDone = true;
	if (Cloth && Bank) { Bank->SetGlow(Cloth, FLinearColor(0.2f, 1.f, 0.2f), 1.8f); }
}

// ---------------------------------------------------------------- torch
AAdvTorch::AAdvTorch()
{
	PrimaryActorTick.bCanEverTick = true;
	MakeRoot(this);
}

void AAdvTorch::Setup(UAdvAssets* A)
{
	USceneComponent* R = GetRootComponent();
	Phase = FMath::FRand() * 10.f;
	UMaterialInstanceDynamic* Wood = A->Lit(this, FLinearColor(0.22f, 0.15f, 0.1f));
	UMaterialInstanceDynamic* Cap = A->Lit(this, FLinearColor(0.3f, 0.3f, 0.33f));
	A->Box(this, R, Wood, FVector(0.f, 0.f, 70.f), FVector(14.f, 14.f, 140.f));
	A->Box(this, R, Cap, FVector(0.f, 0.f, 142.f), FVector(30.f, 30.f, 12.f));

	UMaterialInstanceDynamic* Fire = A->Glow(this, FLinearColor(1.f, 0.55f, 0.15f), 3.f);
	Flame = A->Ball(this, R, Fire, FVector(0.f, 0.f, 172.f), 16.f, FVector(1.f, 1.f, 1.6f), false);

	Light = NewObject<UPointLightComponent>(this);
	Light->SetMobility(EComponentMobility::Movable);
	Light->SetIntensityUnits(ELightUnits::Candelas);
	// Godot energy 1.6, seen from ~2.5 m
	BaseCd = 1.6f * PI * A->ExposureComp * 6.25f;
	Light->SetIntensity(BaseCd);
	Light->SetAttenuationRadius(600.f);
	Light->SetLightColor(Adv::ToLin(FLinearColor(1.f, 0.6f, 0.28f)), true);
	Light->SetCastShadows(false);
	Light->SetRelativeLocation(FVector(0.f, 0.f, 180.f));
	Light->SetupAttachment(R);
	Light->RegisterComponent();
}

void AAdvTorch::Tick(float Dt)
{
	Super::Tick(Dt);
	Age += Dt;
	const float F = 0.82f + 0.18f * FMath::Sin(Age * 9.f + Phase) * FMath::Sin(Age * 3.7f + Phase * 2.f);
	if (Light) { Light->SetIntensity(BaseCd * F); }
	if (Flame)
	{
		const float S = 0.9f + 0.2f * F;
		Flame->SetRelativeScale3D(FVector(S, S, S * 1.5f));
	}
}

// ---------------------------------------------------------------- moving platform
AAdvMover::AAdvMover()
{
	PrimaryActorTick.bCanEverTick = false;
	MakeRoot(this);
}

void AAdvMover::Setup(UAdvAssets* A, float W, float Ln, float Top, const FLinearColor& Srgb)
{
	A->Platform(this, GetRootComponent(), FVector::ZeroVector, W, Ln, Top, Srgb);
}

// ---------------------------------------------------------------- burst particles
AAdvBurst::AAdvBurst()
{
	PrimaryActorTick.bCanEverTick = true;
	MakeRoot(this);
}

void AAdvBurst::Init(UAdvAssets* A, const FLinearColor& Srgb, int32 Amount, float SpeedCm)
{
	Ism = NewObject<UInstancedStaticMeshComponent>(this);
	Ism->SetStaticMesh(A->Cube);
	Ism->SetMobility(EComponentMobility::Movable);
	Ism->SetMaterial(0, A->Glow(this, Srgb, 2.f));
	Ism->SetCastShadow(false);
	Ism->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Ism->SetupAttachment(GetRootComponent());
	Ism->RegisterComponent();

	for (int32 i = 0; i < Amount; ++i)
	{
		const FVector Dir = FMath::VRandCone(FVector::UpVector, FMath::DegreesToRadians(70.f));
		Vel.Add(Dir * FMath::FRandRange(SpeedCm * 0.5f, SpeedCm));
		Pos.Add(FVector::ZeroVector);
		Ism->AddInstance(FTransform(FQuat::Identity, FVector::ZeroVector, FVector(0.14f)));
	}
	SetLifeSpan(Life + 0.15f);
}

void AAdvBurst::Tick(float Dt)
{
	Super::Tick(Dt);
	if (!Ism) { return; }
	Age += Dt;
	const float K = FMath::Clamp(1.f - Age / Life, 0.f, 1.f);
	for (int32 i = 0; i < Pos.Num(); ++i)
	{
		Vel[i].Z -= 1200.f * Dt;
		Pos[i] += Vel[i] * Dt;
		Ism->UpdateInstanceTransform(i, FTransform(FQuat::Identity, Pos[i], FVector(0.14f * K)), false, false, true);
	}
	Ism->MarkRenderStateDirty();
}

// ---------------------------------------------------------------- fireflies
AAdvFireflies::AAdvFireflies()
{
	PrimaryActorTick.bCanEverTick = true;
	MakeRoot(this);
}

void AAdvFireflies::Setup(UAdvAssets* A)
{
	Ism = NewObject<UInstancedStaticMeshComponent>(this);
	Ism->SetStaticMesh(A->Sphere);
	Ism->SetMobility(EComponentMobility::Movable);
	Ism->SetMaterial(0, A->Glow(this, FLinearColor(0.7f, 1.f, 0.4f), 3.f));
	Ism->SetCastShadow(false);
	Ism->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Ism->SetupAttachment(GetRootComponent());
	Ism->RegisterComponent();

	for (int32 i = 0; i < 60; ++i)
	{
		Off.Add(FVector(FMath::FRandRange(-1400.f, 1400.f), FMath::FRandRange(-1400.f, 1400.f), FMath::FRandRange(-300.f, 500.f)));
		Vel.Add(FMath::VRand() * FMath::FRandRange(10.f, 50.f));
		Ph.Add(FMath::FRand() * 6.28f);
		Ism->AddInstance(FTransform(FQuat::Identity, Off[i], FVector(0.07f)));
	}
}

void AAdvFireflies::Tick(float Dt)
{
	Super::Tick(Dt);
	if (!Ism) { return; }
	Age += Dt;
	if (APlayerCameraManager* Cam = UGameplayStatics::GetPlayerCameraManager(this, 0))
	{
		SetActorLocation(Cam->GetCameraLocation());
	}
	for (int32 i = 0; i < Off.Num(); ++i)
	{
		Off[i] += Vel[i] * Dt;
		Off[i].X = FMath::Wrap(Off[i].X, -1400.0, 1400.0);
		Off[i].Y = FMath::Wrap(Off[i].Y, -1400.0, 1400.0);
		Off[i].Z = FMath::Wrap(Off[i].Z, -300.0, 500.0);
		const float Tw = 0.07f * (0.6f + 0.4f * FMath::Sin(Age * 3.f + Ph[i]));
		Ism->UpdateInstanceTransform(i, FTransform(FQuat::Identity, Off[i], FVector(Tw)), false, false, true);
	}
	Ism->MarkRenderStateDirty();
}

// ---------------------------------------------------------------- moon + stars
AAdvSky::AAdvSky()
{
	PrimaryActorTick.bCanEverTick = true;
	MakeRoot(this);
}

void AAdvSky::Setup(UAdvAssets* A)
{
	USceneComponent* R = GetRootComponent();

	// moon: same direction/size as the Godot version, pushed far away
	const FVector MoonRel = Adv::G(-60.0, 48.0, -170.0);
	const float Dist = 30000.f;
	const float K = Dist / MoonRel.Size();
	UMaterialInstanceDynamic* MoonM = A->Glow(this, FLinearColor(0.88f, 0.93f, 1.f), 1.6f);
	A->Ball(this, R, MoonM, MoonRel.GetSafeNormal() * Dist, 700.f * K, FVector::OneVector, false);

	// stars
	UInstancedStaticMeshComponent* Stars = NewObject<UInstancedStaticMeshComponent>(this);
	Stars->SetStaticMesh(A->Sphere);
	Stars->SetMobility(EComponentMobility::Movable);
	Stars->SetMaterial(0, A->Glow(this, FLinearColor(0.85f, 0.9f, 1.f), 4.f));
	Stars->SetCastShadow(false);
	Stars->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Stars->SetupAttachment(R);
	Stars->RegisterComponent();
	FRandomStream Rng(777);
	for (int32 i = 0; i < 160; ++i)
	{
		FVector D = Rng.VRand();
		D.Z = FMath::Abs(D.Z) * 0.9f + 0.08f;
		D.Normalize();
		const float S = Rng.FRandRange(1.2f, 3.2f);
		Stars->AddInstance(FTransform(FQuat::Identity, D * 40000.f, FVector(S)));
	}
}

void AAdvSky::Tick(float Dt)
{
	Super::Tick(Dt);
	if (APlayerCameraManager* Cam = UGameplayStatics::GetPlayerCameraManager(this, 0))
	{
		SetActorLocation(Cam->GetCameraLocation());
	}
}
