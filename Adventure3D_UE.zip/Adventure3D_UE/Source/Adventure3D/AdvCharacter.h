#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "AdvCharacter.generated.h"

class UCameraComponent;
class UPointLightComponent;
class USceneComponent;
class AAdvGameMode;

/**
 * The hero. Movement = Unreal CharacterMovement tuned to the Godot numbers.
 * The visual is built from primitives and animated in code (run, jump, spin, win),
 * exactly like hero_character.gd did with bones.
 */
UCLASS()
class ADVENTURE3D_API AAdvCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	AAdvCharacter();
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	// written by the player controller
	FVector2D MoveVec = FVector2D::ZeroVector; // x = right, y = screen-down (backwards)
	bool bJumpReq = false;
	bool bSpinReq = false;

	// written by the game mode
	bool bWin = false;
	float SpinT = 0.f;

	void SetPlaying(bool bPlay);
	void Shake(float Duration, float AmpCm);
	void TeleportToStart(const FVector& Loc);
	FVector FeetLocation() const { return GetActorLocation() - FVector(0.f, 0.f, 70.f); }

private:
	void BuildHero(AAdvGameMode* GM);
	void UpdateCamera(float Dt);
	void AnimateHero(float Dt);

	UPROPERTY() TObjectPtr<UCameraComponent> Camera;
	UPROPERTY() TObjectPtr<UPointLightComponent> Lantern;
	UPROPERTY() TObjectPtr<USceneComponent> SpinPivot;
	UPROPERTY() TObjectPtr<USceneComponent> FacePivot;
	UPROPERTY() TObjectPtr<USceneComponent> BodyPivot;
	UPROPERTY() TObjectPtr<USceneComponent> ChestPivot;
	UPROPERTY() TObjectPtr<USceneComponent> HipL;
	UPROPERTY() TObjectPtr<USceneComponent> HipR;
	UPROPERTY() TObjectPtr<USceneComponent> KneeL;
	UPROPERTY() TObjectPtr<USceneComponent> KneeR;
	UPROPERTY() TObjectPtr<USceneComponent> ShoulderL;
	UPROPERTY() TObjectPtr<USceneComponent> ShoulderR;
	UPROPERTY() TObjectPtr<USceneComponent> ElbowL;
	UPROPERTY() TObjectPtr<USceneComponent> ElbowR;
	UPROPERTY() TObjectPtr<USceneComponent> HeadPivot;
	UPROPERTY() TObjectPtr<USceneComponent> Scarf;

	bool bPlaying = false;
	bool bImportedHero = false;
	FVector SavedVel = FVector::ZeroVector;

	// camera
	FVector CamOff = FVector(-800.f, 0.f, 500.f);
	float CamFov = 95.f;
	float ShakeT = 0.f, ShakeDur = 0.f, ShakeAmp = 0.f;
	float LanternBaseCd = 100.f;

	// animation state
	float T = 0.f, Phase = 0.f, FaceYaw = 0.f, FacePitch = 0.f, SpinYaw = 0.f;
	float Move = 0.f, Air = 0.f, SpinBlend = 0.f, WinBlend = 0.f;
	bool bWasFloor = true;
	float PrevVelZ = 0.f;
	float DustT = 0.f;
};
