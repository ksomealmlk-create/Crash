#include "AdvHUD.h"
#include "AdvGameMode.h"
#include "AdvPlayerController.h"
#include "AdvCommon.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "Engine/World.h"

void AAdvHUD::Circle(float Cx, float Cy, float R, const FLinearColor& C)
{
	if (Canvas) { Canvas->K2_DrawPolygon(nullptr, FVector2D(Cx, Cy), FVector2D(R, R), 32, C); }
}

void AAdvHUD::TextC(const FString& S, float Cx, float Y, float Scale, const FLinearColor& C)
{
	float W = 0.f, H = 0.f;
	GetTextSize(S, W, H, GEngine->GetLargeFont(), Scale);
	DrawText(S, FLinearColor(0.f, 0.f, 0.f, 0.6f * C.A), Cx - W * 0.5f + 2.f, Y + 2.f, GEngine->GetLargeFont(), Scale);
	DrawText(S, C, Cx - W * 0.5f, Y, GEngine->GetLargeFont(), Scale);
}

void AAdvHUD::Shadowed(const FString& S, float X, float Y, float Scale, const FLinearColor& C)
{
	DrawText(S, FLinearColor(0.f, 0.f, 0.f, 0.6f), X + 2.f, Y + 2.f, GEngine->GetLargeFont(), Scale);
	DrawText(S, C, X, Y, GEngine->GetLargeFont(), Scale);
}

void AAdvHUD::DrawHUD()
{
	Super::DrawHUD();
	if (!Canvas) { return; }

	AAdvGameMode* GM = GetWorld() ? GetWorld()->GetAuthGameMode<AAdvGameMode>() : nullptr;
	AAdvPlayerController* PC = Cast<AAdvPlayerController>(GetOwningPlayerController());
	if (!GM) { return; }

	const int32 W = Canvas->SizeX;
	const int32 H = Canvas->SizeY;
	const float S = H / 720.f;

	// red flash when hurt
	if (GM->HurtFlash > 0.f)
	{
		DrawRect(FLinearColor(1.f, 0.05f, 0.05f, GM->HurtFlash * 0.35f), 0.f, 0.f, (float)W, (float)H);
	}

	// score + lives
	Shadowed(FString::Printf(TEXT("Fruits: %d"), GM->Fruits), 24.f * S, 18.f * S, 1.5f * S, FLinearColor(1.f, 0.85f, 0.3f));
	for (int32 i = 0; i < GM->Lives; ++i)
	{
		Circle(40.f * S + i * 46.f * S, 92.f * S, 15.f * S, FLinearColor(1.f, 0.2f, 0.25f, 0.95f));
	}

	if (GM->State == EAdvState::Play || GM->State == EAdvState::Pause)
	{
		// SPIN / JUMP hints
		Circle(W * 0.62f, H * 0.83f, H * 0.105f, FLinearColor(0.2f, 0.5f, 1.f, 0.30f));
		Circle(W * 0.62f, H * 0.83f, H * 0.085f, FLinearColor(0.2f, 0.5f, 1.f, 0.25f));
		TextC(TEXT("SPIN"), W * 0.62f, H * 0.83f - 18.f * S, 1.4f * S, FLinearColor(1.f, 1.f, 1.f, 0.85f));
		Circle(W * 0.87f, H * 0.83f, H * 0.105f, FLinearColor(0.2f, 0.9f, 0.3f, 0.30f));
		Circle(W * 0.87f, H * 0.83f, H * 0.085f, FLinearColor(0.2f, 0.9f, 0.3f, 0.25f));
		TextC(TEXT("JUMP"), W * 0.87f, H * 0.83f - 18.f * S, 1.4f * S, FLinearColor(1.f, 1.f, 1.f, 0.85f));

		// pause + quality buttons
		const Adv::FUiRect P = Adv::PauseButtonRect(W, H);
		const Adv::FUiRect Q = Adv::QualityButtonRect(W, H);
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.45f), P.X, P.Y, P.W, P.H);
		TextC(TEXT("II"), P.X + P.W * 0.5f, P.Y + P.H * 0.5f - 18.f * S, 1.5f * S, FLinearColor::White);
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.45f), Q.X, Q.Y, Q.W, Q.H);
		TextC(GM->bFxOn ? TEXT("HD") : TEXT("LD"), Q.X + Q.W * 0.5f, Q.Y + Q.H * 0.5f - 18.f * S, 1.5f * S, FLinearColor::White);

		// floating stick
		if (PC && PC->bStickActive)
		{
			const FVector2D Base = PC->StickStart;
			const FVector2D Knob = Base + PC->StickVec * (80.f * S);
			Circle(Base.X, Base.Y, 80.f * S, FLinearColor(1.f, 1.f, 1.f, 0.18f));
			Circle(Knob.X, Knob.Y, 35.f * S, FLinearColor(1.f, 1.f, 1.f, 0.45f));
		}
	}

	// menu / pause / game over / win panel
	if (GM->State != EAdvState::Play)
	{
		DrawRect(FLinearColor(0.f, 0.f, 0.02f, 0.55f), 0.f, 0.f, (float)W, (float)H);

		TArray<FString> Lines;
		GM->PanelTitle.ParseIntoArrayLines(Lines);
		float Y = H * 0.5f - 130.f * S - (Lines.Num() - 1) * 40.f * S;
		for (const FString& L : Lines)
		{
			TextC(L, W * 0.5f, Y, 3.2f * S, FLinearColor(1.f, 0.92f, 0.6f));
			Y += 80.f * S;
		}

		const Adv::FUiRect B = Adv::MainButtonRect(W, H);
		DrawRect(FLinearColor(1.f, 1.f, 1.f, 0.9f), B.X - 3.f * S, B.Y - 3.f * S, B.W + 6.f * S, B.H + 6.f * S);
		DrawRect(FLinearColor(0.1f, 0.45f, 0.85f, 1.f), B.X, B.Y, B.W, B.H);
		TextC(GM->PanelButton, B.X + B.W * 0.5f, B.Y + B.H * 0.5f - 22.f * S, 2.2f * S, FLinearColor::White);
	}
}
