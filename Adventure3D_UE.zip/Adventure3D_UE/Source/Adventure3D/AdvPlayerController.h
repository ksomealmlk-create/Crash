#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "AdvPlayerController.generated.h"

/** Touch controls like the Godot version: left half = floating stick, then SPIN zone, then JUMP zone. */
UCLASS()
class ADVENTURE3D_API AAdvPlayerController : public APlayerController
{
	GENERATED_BODY()

public:
	AAdvPlayerController();
	virtual void PlayerTick(float DeltaTime) override;

	// read by the HUD
	bool bStickActive = false;
	FVector2D StickStart = FVector2D::ZeroVector;
	FVector2D StickVec = FVector2D::ZeroVector; // -1..1

private:
	bool FingerDown[5] = { false, false, false, false, false };
	int32 StickFinger = -1;
};
