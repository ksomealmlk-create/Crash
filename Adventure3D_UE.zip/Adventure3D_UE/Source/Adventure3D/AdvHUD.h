#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "AdvHUD.generated.h"

/** Canvas HUD: score, touch buttons, floating stick, menu panel. No UMG assets needed. */
UCLASS()
class ADVENTURE3D_API AAdvHUD : public AHUD
{
	GENERATED_BODY()

public:
	virtual void DrawHUD() override;

private:
	void Circle(float Cx, float Cy, float R, const FLinearColor& C);
	void TextC(const FString& S, float Cx, float Y, float Scale, const FLinearColor& C);
	void Shadowed(const FString& S, float X, float Y, float Scale, const FLinearColor& C);
};
