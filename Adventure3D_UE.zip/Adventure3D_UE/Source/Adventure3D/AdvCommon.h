#pragma once

#include "CoreMinimal.h"

enum class EAdvState : uint8 { Menu, Play, Pause, Over, Win };
enum class EAdvSfx : uint8 { Jump, Spin, Crate, Stomp, Hurt, Check, Win, Lose, Num };

namespace Adv
{
	// Godot (x right, y up, z toward camera) in meters  ->  Unreal (X forward, Y right, Z up) in cm.
	// The level runs toward -Z in Godot, so it runs toward +X here.
	FORCEINLINE FVector G(double x, double y, double z) { return FVector(-z * 100.0, x * 100.0, y * 100.0); }

	// Godot colors are sRGB; Unreal material parameters are linear.
	FORCEINLINE FLinearColor ToLin(const FLinearColor& S)
	{
		return FLinearColor(FMath::Pow(S.R, 2.2f), FMath::Pow(S.G, 2.2f), FMath::Pow(S.B, 2.2f), 1.f);
	}
	FORCEINLINE FLinearColor Lighten(const FLinearColor& C, float A)
	{
		return FLinearColor(FMath::Lerp(C.R, 1.f, A), FMath::Lerp(C.G, 1.f, A), FMath::Lerp(C.B, 1.f, A), 1.f);
	}
	FORCEINLINE FLinearColor Darken(const FLinearColor& C, float A)
	{
		return FLinearColor(C.R * (1.f - A), C.G * (1.f - A), C.B * (1.f - A), 1.f);
	}

	constexpr float JumpV = 1000.f;      // cm/s  (Godot 10 m/s)
	constexpr float SpinTime = 0.45f;
	constexpr float SpinRadius = 230.f;  // cm

	struct FUiRect
	{
		float X, Y, W, H;
		FUiRect(float InX = 0.f, float InY = 0.f, float InW = 0.f, float InH = 0.f) : X(InX), Y(InY), W(InW), H(InH) {}
		bool Contains(float PX, float PY) const { return PX >= X && PX <= X + W && PY >= Y && PY <= Y + H; }
	};

	// Same layout as the Godot UI (designed for 720 px height).
	FORCEINLINE FUiRect MainButtonRect(int32 SW, int32 SH)
	{
		const float S = SH / 720.f;
		return FUiRect(SW * 0.5f - 180.f * S, SH * 0.5f + 20.f * S, 360.f * S, 110.f * S);
	}
	FORCEINLINE FUiRect PauseButtonRect(int32 SW, int32 SH)
	{
		const float S = SH / 720.f;
		return FUiRect(SW - 120.f * S, 20.f * S, 90.f * S, 90.f * S);
	}
	FORCEINLINE FUiRect QualityButtonRect(int32 SW, int32 SH)
	{
		const float S = SH / 720.f;
		return FUiRect(SW - 230.f * S, 20.f * S, 90.f * S, 90.f * S);
	}
}
