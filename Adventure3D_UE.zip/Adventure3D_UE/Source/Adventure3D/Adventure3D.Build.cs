using UnrealBuildTool;

public class Adventure3D : ModuleRules
{
	public Adventure3D(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core", "CoreUObject", "Engine", "InputCore", "AssetRegistry"
		});
	}
}
