#include "AdvCharacter.h"
#include "AdvAssets.h"
#include "AdvCommon.h"
#include "AdvGameMode.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/SceneComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Engine/World.h"

namespace
{
	constexpr float RAD2DEG = 57.2957795f;
	constexpr float HeroScale = 1.5f;
	constexpr float LegSwing = 0.9f;
	constexpr float ArmSwing = 0.8f;

	// camera zones copied from main.gd: z range (Godot meters) -> camera offset (y up, z back)
	struct FCamZone { float A, B, Y, Z; };
	const FCamZone CamZones[] = {
		{  12.f, -13.f, 5.0f,  8.0f },
		{ -13.f, -30.f, 6.5f,  9.5f },
		{ -30.f, -47.f, 3.6f,  6.0f },
		{ -47.f, -66.f, 6.0f, 10.5f },
		{ -66.f, -72.f, 5.0f,  8.0f },
		{ -72.f, -92.f, 2.2f,  5.5f },
		{ -92.f, -130.f, 7.0f, 10.0f },
	};
}

AAdvCharacter::AAdvCharacter()
{
	PrimaryActorTick.bCanEverTick = true;
	bUseControllerRotationYaw = false;
	bUseControllerRotationPitch = false;
	bUseControllerRotationRoll = false;

	GetCapsuleComponent()->InitCapsuleSize(40.f, 80.f); // Godot capsule: radius 0.4, height 1.6

	UCharacterMovementComponent* M = GetCharacterMovement();
	M->bOrientRotationToMovement = false;
	M->MaxWalkSpeed = 700.f;              // SPEED 7
	M->MaxAcceleration = 14000.f;         // Godot sets velocity instantly
	M->BrakingDecelerationWalking = 14000.f;
	M->BrakingDecelerationFalling = 14000.f;
	M->GroundFriction = 16.f;
	M->AirControl = 1.f;
	M->GravityScale = 28.f / 9.8f;        // GRAV 28
	M->JumpZVelocity = Adv::JumpV;
	M->MaxStepHeight = 25.f;

	Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Cam"));
	Camera->SetupAttachment(GetCapsuleComponent());
	Camera->SetUsingAbsoluteLocation(true);
	Camera->SetUsingAbsoluteRotation(true);
	Camera->bUsePawnControlRotation = false;
	Camera->FieldOfView = CamFov;
}

void AAdvCharacter::BeginPlay()
{
	Super::BeginPlay();
	GetCharacterMovement()->DisableMovement(); // frozen until the player presses START

	AAdvGameMode* GM = GetWorld()->GetAuthGameMode<AAdvGameMode>();
	if (GM) { BuildHero(GM); }

	Camera->SetWorldLocation(GetActorLocation() + CamOff);
}

void AAdvCharacter::BuildHero(AAdvGameMode* GM)
{
	UAdvAssets* A = GM->Assets;
	USceneComponent* Cap = GetCapsuleComponent();

	// lantern that follows the player (Godot: energy 1.2, range 7 m)
	Lantern = NewObject<UPointLightComponent>(this);
	Lantern->SetMobility(EComponentMobility::Movable);
	Lantern->SetIntensityUnits(ELightUnits::Candelas);
	LanternBaseCd = 1.2f * PI * A->ExposureComp * 6.25f;
	Lantern->SetIntensity(LanternBaseCd);
	Lantern->SetAttenuationRadius(700.f);
	Lantern->SetLightColor(Adv::ToLin(FLinearColor(1.f, 0.78f, 0.45f)), true);
	Lantern->SetCastShadows(false);
	Lantern->SetupAttachment(Cap);
	Lantern->SetRelativeLocation(Adv::G(0, 1.2, 0.4));
	Lantern->RegisterComponent();

	SpinPivot = A->Pivot(this, Cap, FVector::ZeroVector);
	FacePivot = A->Pivot(this, SpinPivot, FVector(0.f, 0.f, -80.f)); // feet at capsule bottom
	FacePivot->SetRelativeScale3D(FVector(HeroScale));
	BodyPivot = A->Pivot(this, FacePivot, FVector::ZeroVector);

	// ---- optional: your own hero.glb after Tools/SetupAssets.py ----
	if (GM->bUseImportedHero)
	{
		UMaterialInterface* Vc = A->VertexColorBase;
		if (A->ImportedModel(this, BodyPivot, TEXT("Hero"), 108.f, FVector(0.f, 0.f, 54.f), Vc))
		{
			bImportedHero = true;
			return;
		}
	}

	// ---- built-in hero made of primitives ----
	UMaterialInstanceDynamic* Skin  = A->Lit(this, FLinearColor(0.95f, 0.75f, 0.6f), 0.6f);
	UMaterialInstanceDynamic* Shirt = A->Lit(this, FLinearColor(0.15f, 0.5f, 0.9f), 0.6f);
	UMaterialInstanceDynamic* Pants = A->Lit(this, FLinearColor(0.18f, 0.2f, 0.32f));
	UMaterialInstanceDynamic* Boots = A->Lit(this, FLinearColor(0.3f, 0.2f, 0.12f));
	UMaterialInstanceDynamic* Gold  = A->Lit(this, FLinearColor(0.95f, 0.72f, 0.2f), 0.35f);
	UMaterialInstanceDynamic* Hood  = A->Lit(this, FLinearColor(0.8f, 0.2f, 0.2f));
	UMaterialInstanceDynamic* ScarfM = A->Lit(this, FLinearColor(1.f, 0.35f, 0.2f));
	UMaterialInstanceDynamic* Pack  = A->Lit(this, FLinearColor(0.4f, 0.26f, 0.15f));
	UMaterialInstanceDynamic* White = A->Lit(this, FLinearColor(1.f, 1.f, 1.f), 0.3f);
	UMaterialInstanceDynamic* EyeGlow = A->Glow(this, FLinearColor(0.4f, 0.9f, 1.f), 2.5f);
	UMaterialInstanceDynamic* LampGlow = A->Glow(this, FLinearColor(1.f, 0.7f, 0.25f), 3.f);

	// legs
	for (int32 side = -1; side <= 1; side += 2)
	{
		USceneComponent* Hip = A->Pivot(this, BodyPivot, FVector(0.f, side * 11.f, 42.f));
		A->Tube(this, Hip, Pants, FVector(0.f, 0.f, -9.f), 6.5f, 18.f);
		USceneComponent* Knee = A->Pivot(this, Hip, FVector(0.f, 0.f, -18.f));
		A->Tube(this, Knee, Pants, FVector(0.f, 0.f, -8.5f), 5.5f, 17.f);
		A->Box(this, Knee, Boots, FVector(4.f, 0.f, -20.5f), FVector(20.f, 11.f, 7.f));
		if (side < 0) { HipL = Hip; KneeL = Knee; } else { HipR = Hip; KneeR = Knee; }
	}

	// pelvis + torso
	A->Box(this, BodyPivot, Pants, FVector(0.f, 0.f, 45.f), FVector(20.f, 30.f, 12.f));
	ChestPivot = A->Pivot(this, BodyPivot, FVector(0.f, 0.f, 50.f));
	A->Box(this, ChestPivot, Shirt, FVector(0.f, 0.f, 14.f), FVector(22.f, 34.f, 28.f));
	A->Box(this, ChestPivot, Gold, FVector(0.f, 0.f, -2.f), FVector(23.f, 35.f, 4.f));
	A->Box(this, ChestPivot, Gold, FVector(-12.f, 0.f, -2.f), FVector(2.f, 8.f, 6.f));
	A->Box(this, ChestPivot, Pack, FVector(-15.f, 0.f, 14.f), FVector(10.f, 22.f, 26.f));
	A->Ball(this, ChestPivot, LampGlow, FVector(-19.f, 9.f, 24.f), 3.5f, FVector::OneVector, false);

	// arms
	for (int32 side = -1; side <= 1; side += 2)
	{
		USceneComponent* Sh = A->Pivot(this, ChestPivot, FVector(0.f, side * 20.f, 26.f));
		A->Ball(this, Sh, Shirt, FVector::ZeroVector, 6.f);
		A->Tube(this, Sh, Shirt, FVector(0.f, 0.f, -8.f), 4.5f, 16.f);
		USceneComponent* El = A->Pivot(this, Sh, FVector(0.f, 0.f, -16.f));
		A->Tube(this, El, Skin, FVector(0.f, 0.f, -7.f), 4.f, 14.f);
		A->Ball(this, El, Skin, FVector(0.f, 0.f, -15.f), 4.5f);
		if (side < 0) { ShoulderL = Sh; ElbowL = El; } else { ShoulderR = Sh; ElbowR = El; }
	}

	// head: face looks toward +X
	HeadPivot = A->Pivot(this, ChestPivot, FVector(0.f, 0.f, 36.f));
	A->Ball(this, HeadPivot, Skin, FVector(0.f, 0.f, 8.f), 13.f);
	A->Tube(this, HeadPivot, Skin, FVector(0.f, 0.f, -2.f), 4.f, 8.f);
	A->Ball(this, HeadPivot, Skin, FVector(13.f, 0.f, 5.f), 2.5f);
	for (int32 side = -1; side <= 1; side += 2)
	{
		A->Ball(this, HeadPivot, White, FVector(10.5f, side * 5.f, 10.f), 3.4f, FVector::OneVector, false);
		A->Ball(this, HeadPivot, EyeGlow, FVector(13.2f, side * 5.f, 10.f), 1.9f, FVector::OneVector, false);
	}
	A->Spike(this, HeadPivot, Hood, FVector(-3.f, 0.f, 22.f), 15.f, 20.f, FRotator(20.f, 0.f, 0.f));
	A->Tube(this, HeadPivot, Hood, FVector(0.f, 0.f, 15.f), 13.5f, 4.f);

	// scarf
	A->Box(this, ChestPivot, ScarfM, FVector(0.f, 0.f, 31.f), FVector(24.f, 38.f, 5.f));
	Scarf = A->Pivot(this, ChestPivot, FVector(-12.f, 8.f, 30.f));
	A->Box(this, Scarf, ScarfM, FVector(0.f, 0.f, -12.f), FVector(4.f, 9.f, 24.f));
}

void AAdvCharacter::SetPlaying(bool bPlay)
{
	if (bPlay == bPlaying) { return; }
	bPlaying = bPlay;
	UCharacterMovementComponent* M = GetCharacterMovement();
	if (bPlay)
	{
		M->SetMovementMode(MOVE_Falling);
		M->Velocity = SavedVel;
	}
	else
	{
		SavedVel = M->Velocity;
		M->Velocity = FVector::ZeroVector;
		M->DisableMovement();
		MoveVec = FVector2D::ZeroVector;
	}
}

void AAdvCharacter::TeleportToStart(const FVector& Loc)
{
	SetActorLocation(Loc, false, nullptr, ETeleportType::TeleportPhysics);
	GetCharacterMovement()->Velocity = FVector::ZeroVector;
	SavedVel = FVector::ZeroVector;
	SpinT = 0.f;
	SpinYaw = 0.f;
}

void AAdvCharacter::Shake(float Duration, float AmpCm)
{
	ShakeT = ShakeDur = Duration;
	ShakeAmp = AmpCm;
}

void AAdvCharacter::Tick(float Dt)
{
	Super::Tick(Dt);
	T += Dt;
	AAdvGameMode* GM = GetWorld()->GetAuthGameMode<AAdvGameMode>();
	UCharacterMovementComponent* M = GetCharacterMovement();

	if (bPlaying && GM)
	{
		const FVector2D In = MoveVec;
		if (In.SizeSquared() > 0.0004f)
		{
			AddMovementInput(FVector(-In.Y, In.X, 0.0).GetSafeNormal(), FMath::Min(1.f, (float)In.Size()));
		}
		if (bJumpReq && M->IsMovingOnGround())
		{
			LaunchCharacter(FVector(0.f, 0.f, Adv::JumpV), false, true);
			GM->PlaySfx(EAdvSfx::Jump);
			GM->Burst(FeetLocation(), FLinearColor::White, 6, 250.f);
		}
		if (bSpinReq && SpinT <= 0.f)
		{
			SpinT = Adv::SpinTime;
			GM->PlaySfx(EAdvSfx::Spin);
		}
		if (SpinT > 0.f)
		{
			SpinT -= Dt;
			SpinYaw += Dt * (4.f * PI / Adv::SpinTime) * RAD2DEG;
			if (SpinT <= 0.f) { SpinT = 0.f; SpinYaw = 0.f; }
		}

		// landing + running dust
		const FVector V = GetVelocity();
		const bool bFloor = M->IsMovingOnGround();
		const float Hs = FVector2D(V.X, V.Y).Size();
		if (bFloor && !bWasFloor && PrevVelZ < -500.f)
		{
			GM->Burst(FeetLocation(), FLinearColor::White, 8, 300.f);
		}
		DustT -= Dt;
		if (bFloor && DustT <= 0.f && Hs > 400.f)
		{
			DustT = 0.18f;
			GM->Burst(FeetLocation(), FLinearColor(0.9f, 0.85f, 0.7f), 3, 150.f);
		}
		bWasFloor = bFloor;
		PrevVelZ = V.Z;
	}
	bJumpReq = false;
	bSpinReq = false;

	if (Lantern)
	{
		const float F = 0.82f + 0.18f * FMath::Sin(T * 9.f + 1.7f) * FMath::Sin(T * 3.7f + 3.4f);
		Lantern->SetIntensity(LanternBaseCd * F);
	}

	AnimateHero(Dt);
	UpdateCamera(Dt);
}

void AAdvCharacter::UpdateCamera(float Dt)
{
	const FVector P = GetActorLocation();
	const float Gz = -P.X / 100.f; // Godot z in meters

	FVector Target = Adv::G(0, 6, 9);
	for (const FCamZone& Z : CamZones)
	{
		if (Gz <= Z.A && Gz > Z.B) { Target = Adv::G(0, Z.Y, Z.Z); break; }
	}
	CamOff += (Target - CamOff) * FMath::Min(1.f, Dt * 2.5f);

	FVector Want = P + CamOff;
	Want.Y = P.Y * 0.8f;
	FVector Cur = Camera->GetComponentLocation();
	Cur += (Want - Cur) * FMath::Min(1.f, Dt * 6.f);

	FVector Shk = FVector::ZeroVector;
	if (ShakeT > 0.f)
	{
		ShakeT -= Dt;
		const float K = FMath::Clamp(ShakeT / FMath::Max(ShakeDur, 0.01f), 0.f, 1.f);
		Shk = FVector(0.f, FMath::FRandRange(-1.f, 1.f), FMath::FRandRange(-1.f, 1.f)) * ShakeAmp * K;
	}

	const FVector LookAt = P + Adv::G(0, 0.5, -2.0);
	const FRotator Rot = (LookAt - Cur).Rotation();
	Camera->SetWorldLocationAndRotation(Cur + Shk, Rot);

	const float Hs = FVector2D(GetVelocity().X, GetVelocity().Y).Size() / 100.f;
	CamFov = FMath::FInterpTo(CamFov, 95.f + Hs * 1.5f, Dt, 4.f);
	Camera->SetFieldOfView(CamFov);
}

void AAdvCharacter::AnimateHero(float Dt)
{
	if (!BodyPivot) { return; }

	const FVector V = GetVelocity();
	const float Hs = FVector2D(V.X, V.Y).Size() / 100.f; // m/s
	const bool bAir = GetCharacterMovement()->IsFalling();

	if (Hs > 0.5f)
	{
		const float Target = FMath::RadiansToDegrees(FMath::Atan2(V.Y, V.X));
		FaceYaw = FMath::RInterpTo(FRotator(0.f, FaceYaw, 0.f), FRotator(0.f, Target, 0.f), Dt, 12.f).Yaw;
	}
	Move = FMath::FInterpConstantTo(Move, FMath::Clamp(Hs / 7.f, 0.f, 1.f), Dt, 8.f);
	Air = FMath::FInterpConstantTo(Air, bAir ? 1.f : 0.f, Dt, 10.f);
	SpinBlend = FMath::FInterpConstantTo(SpinBlend, SpinT > 0.f ? 1.f : 0.f, Dt, 14.f);
	WinBlend = FMath::FInterpConstantTo(WinBlend, bWin ? 1.f : 0.f, Dt, 6.f);
	if (!bAir) { Phase += Dt * Hs * 1.7f; }

	const float S = FMath::Sin(Phase);
	const float C = FMath::Cos(Phase);
	const float Sw = Move * (1.f - 0.6f * Air);

	SpinPivot->SetRelativeRotation(FRotator(0.f, SpinYaw, 0.f));
	const float LeanTarget = -0.18f * Move * (1.f - Air) * RAD2DEG;
	FacePitch = FMath::FInterpTo(FacePitch, LeanTarget, Dt, 10.f);
	FacePivot->SetRelativeRotation(FRotator(FacePitch, FaceYaw, 0.f));

	if (bImportedHero || !HipL)
	{
		// imported model: only whole-body motion
		BodyPivot->SetRelativeLocation(FVector(0.f, 0.f, (FMath::Abs(S) * 6.f * Sw + FMath::Abs(FMath::Sin(T * 8.f)) * 12.f * WinBlend) / HeroScale));
		return;
	}

	// Godot convention in this block: positive = limb swings BACK. Converted to Unreal pitch at the end (-value).
	float LLeg = S * LegSwing * Sw;
	float RLeg = -S * LegSwing * Sw;
	float LArm = -S * ArmSwing * Sw;
	float RArm = S * ArmSwing * Sw;
	float LKnee = FMath::Max(0.f, -C) * 1.3f * Move;
	float RKnee = FMath::Max(0.f, C) * 1.3f * Move;
	float LElb = -Move * (0.9f + 0.25f * S);
	float RElb = -Move * (0.9f - 0.25f * S);

	const float Breath = FMath::Sin(T * 2.f) * 0.03f * (1.f - Move);
	LArm += Breath; RArm += Breath;

	LLeg -= 0.5f * Air; RLeg -= 0.5f * Air;     // jump / fall: legs tucked, arms up
	LKnee += 0.8f * Air; RKnee += 0.8f * Air;
	LArm -= 0.9f * Air; RArm -= 0.9f * Air;

	LArm -= 2.6f * WinBlend; RArm -= 2.6f * WinBlend; // victory: arms straight up
	LElb *= (1.f - WinBlend); RElb *= (1.f - WinBlend);

	LElb *= (1.f - SpinBlend); RElb *= (1.f - SpinBlend); // spin: arms out to the sides
	const float Out = 1.3f * SpinBlend * RAD2DEG;

	HipL->SetRelativeRotation(FRotator(-LLeg * RAD2DEG, 0.f, 0.f));
	HipR->SetRelativeRotation(FRotator(-RLeg * RAD2DEG, 0.f, 0.f));
	KneeL->SetRelativeRotation(FRotator(-LKnee * RAD2DEG, 0.f, 0.f));
	KneeR->SetRelativeRotation(FRotator(-RKnee * RAD2DEG, 0.f, 0.f));
	ShoulderL->SetRelativeRotation(FRotator(-LArm * RAD2DEG, 0.f, -Out));
	ShoulderR->SetRelativeRotation(FRotator(-RArm * RAD2DEG, 0.f, Out));
	ElbowL->SetRelativeRotation(FRotator(-LElb * RAD2DEG, 0.f, 0.f));
	ElbowR->SetRelativeRotation(FRotator(-RElb * RAD2DEG, 0.f, 0.f));
	ChestPivot->SetRelativeRotation(FRotator(0.f, S * 0.15f * Sw * RAD2DEG, 0.f));
	if (HeadPivot) { HeadPivot->SetRelativeRotation(FRotator(0.f, -S * 0.1f * Sw * RAD2DEG, 0.f)); }
	if (Scarf) { Scarf->SetRelativeRotation(FRotator((25.f + 25.f * FMath::Sin(T * 9.f)) * Move + 8.f * Air, 0.f, 0.f)); }

	BodyPivot->SetRelativeLocation(FVector(0.f, 0.f, (FMath::Abs(S) * 6.f * Sw + FMath::Abs(FMath::Sin(T * 8.f)) * 12.f * WinBlend) / HeroScale));
}
