#include "AdvPlayerController.h"
#include "AdvCharacter.h"
#include "AdvGameMode.h"
#include "AdvCommon.h"
#include "Engine/World.h"
#include "InputCoreTypes.h"

AAdvPlayerController::AAdvPlayerController()
{
	bShowMouseCursor = false;
}

void AAdvPlayerController::PlayerTick(float DeltaTime)
{
	Super::PlayerTick(DeltaTime);

	AAdvGameMode* GM = GetWorld()->GetAuthGameMode<AAdvGameMode>();
	AAdvCharacter* P = Cast<AAdvCharacter>(GetPawn());
	if (!GM || !P) { return; }

	int32 W = 0, H = 0;
	GetViewportSize(W, H);
	if (W <= 0 || H <= 0) { return; }
	const float S = H / 720.f;
	const bool bPlaying = (GM->State == EAdvState::Play);

	const Adv::FUiRect MainR = Adv::MainButtonRect(W, H);
	const Adv::FUiRect PauseR = Adv::PauseButtonRect(W, H);
	const Adv::FUiRect QualR = Adv::QualityButtonRect(W, H);

	// ---------------- touch ----------------
	for (int32 i = 0; i < 5; ++i)
	{
		float X = 0.f, Y = 0.f;
		bool bDown = false;
		GetInputTouchState(static_cast<ETouchIndex::Type>(i), X, Y, bDown);

		if (bDown && !FingerDown[i])
		{
			FingerDown[i] = true;
			if (!bPlaying)
			{
				if (MainR.Contains(X, Y)) { GM->OnMainButton(); }
			}
			else if (PauseR.Contains(X, Y)) { GM->OnPause(); }
			else if (QualR.Contains(X, Y)) { GM->OnQuality(); }
			else if (X < W * 0.5f)
			{
				if (StickFinger < 0)
				{
					StickFinger = i;
					StickStart = FVector2D(X, Y);
					StickVec = FVector2D::ZeroVector;
					bStickActive = true;
				}
			}
			else if (X < W * 0.75f) { P->bSpinReq = true; }
			else { P->bJumpReq = true; }
		}
		else if (bDown && FingerDown[i])
		{
			if (i == StickFinger)
			{
				FVector2D D = (FVector2D(X, Y) - StickStart) / (100.f * S);
				if (D.Size() > 1.f) { D = D.GetSafeNormal(); }
				StickVec = D;
			}
		}
		else if (!bDown && FingerDown[i])
		{
			FingerDown[i] = false;
			if (i == StickFinger)
			{
				StickFinger = -1;
				bStickActive = false;
				StickVec = FVector2D::ZeroVector;
			}
		}
	}

	if (!bPlaying)
	{
		StickFinger = -1;
		bStickActive = false;
		StickVec = FVector2D::ZeroVector;
	}

	// ---------------- keyboard (handy when testing in the editor) ----------------
	FVector2D Key(0.0, 0.0);
	if (IsInputKeyDown(EKeys::A) || IsInputKeyDown(EKeys::Left))  { Key.X -= 1.0; }
	if (IsInputKeyDown(EKeys::D) || IsInputKeyDown(EKeys::Right)) { Key.X += 1.0; }
	if (IsInputKeyDown(EKeys::W) || IsInputKeyDown(EKeys::Up))    { Key.Y -= 1.0; }
	if (IsInputKeyDown(EKeys::S) || IsInputKeyDown(EKeys::Down))  { Key.Y += 1.0; }

	if (WasInputKeyJustPressed(EKeys::Enter) && !bPlaying) { GM->OnMainButton(); }
	if (WasInputKeyJustPressed(EKeys::Escape) || WasInputKeyJustPressed(EKeys::P)) { GM->OnPause(); }

	if (bPlaying)
	{
		if (WasInputKeyJustPressed(EKeys::SpaceBar)) { P->bJumpReq = true; }
		if (WasInputKeyJustPressed(EKeys::E) || WasInputKeyJustPressed(EKeys::LeftShift)) { P->bSpinReq = true; }
		P->MoveVec = !Key.IsNearlyZero() ? Key.GetSafeNormal() : StickVec;
	}
	else
	{
		P->MoveVec = FVector2D::ZeroVector;
	}
}
