#include "AdvGameMode.h"
#include "AdvAssets.h"
#include "AdvActors.h"
#include "AdvCharacter.h"
#include "AdvPlayerController.h"
#include "AdvHUD.h"
#include "Engine/World.h"
#include "Engine/DirectionalLight.h"
#include "Engine/ExponentialHeightFog.h"
#include "Engine/PostProcessVolume.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/ExponentialHeightFogComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/AudioComponent.h"
#include "Components/PointLightComponent.h"
#include "GameFramework/PlayerStart.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundWaveProcedural.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "TimerManager.h"

using namespace Adv;

AAdvGameMode::AAdvGameMode()
{
	PrimaryActorTick.bCanEverTick = true;
	DefaultPawnClass = AAdvCharacter::StaticClass();
	PlayerControllerClass = AAdvPlayerController::StaticClass();
	HUDClass = AAdvHUD::StaticClass();
	Assets = CreateDefaultSubobject<UAdvAssets>(TEXT("Assets"));
}

void AAdvGameMode::InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage)
{
	Super::InitGame(MapName, Options, ErrorMessage);
	Assets->ExposureComp = 1.2f * FMath::Pow(2.f, ExposureEV);

	StartPos = G(0, 1.5, 0);
	RespawnPos = StartPos;

	// the engine's empty map has no PlayerStart, so make one
	FActorSpawnParameters P;
	P.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	GetWorld()->SpawnActor<APlayerStart>(StartPos, FRotator::ZeroRotator, P);
}

void AAdvGameMode::BeginPlay()
{
	Super::BeginPlay();
	BuildSounds();
	BuildEnvironment();
	BuildForest();
	BuildLevel();

	Player = Cast<AAdvCharacter>(UGameplayStatics::GetPlayerPawn(this, 0));
	if (Player) { Player->TeleportToStart(StartPos); }

	ShowPanel(TEXT("ADVENTURE 3D"), TEXT("START"));
	State = EAdvState::Menu;
}

// ===================================================================== environment
void AAdvGameMode::BuildEnvironment()
{
	UWorld* W = GetWorld();
	const float Comp = Assets->ExposureComp;

	// ---- moonlight ----
	{
		const FTransform Tr(FRotator(-38.f, 35.f, 0.f));
		Sun = W->SpawnActorDeferred<ADirectionalLight>(ADirectionalLight::StaticClass(), Tr);
		Sun->GetRootComponent()->SetMobility(EComponentMobility::Movable);
		UGameplayStatics::FinishSpawningActor(Sun, Tr);
		UDirectionalLightComponent* L = Cast<UDirectionalLightComponent>(Sun->GetLightComponent());
		L->SetLightColor(ToLin(FLinearColor(0.55f, 0.66f, 1.f)), true);
		L->SetIntensity(0.85f * PI * Comp);
		L->SetCastShadows(true);
		L->DynamicShadowDistanceMovableLight = 4500.f;
		L->DynamicShadowCascades = 2;
		L->CascadeDistributionExponent = 3.f;
	}

	// ---- fog ----
	{
		AExponentialHeightFog* Fog = W->SpawnActor<AExponentialHeightFog>(FVector(0.f, 0.f, 0.f), FRotator::ZeroRotator);
		UExponentialHeightFogComponent* F = Fog->GetComponent();
		F->SetFogDensity(FogDensity);
		F->SetFogHeightFalloff(0.02f);
		F->SetFogInscatteringColor(ToLin(FLinearColor(0.06f, 0.09f, 0.16f)) * Comp);
		F->SetFogMaxOpacity(0.92f);
		F->SetFogCutoffDistance(25000.f); // keep moon + stars un-fogged
		F->SetVolumetricFog(false);
	}

	// ---- post process: fixed exposure, bloom, vignette, grading ----
	{
		Post = W->SpawnActor<APostProcessVolume>(FVector::ZeroVector, FRotator::ZeroRotator);
		Post->bUnbound = true;
		Post->BlendWeight = 1.f;
		FPostProcessSettings& S = Post->Settings;
		S.bOverride_AutoExposureMethod = true;
		S.AutoExposureMethod = EAutoExposureMethod::AEM_Basic;
		S.bOverride_AutoExposureMinBrightness = true;
		S.AutoExposureMinBrightness = ExposureEV;
		S.bOverride_AutoExposureMaxBrightness = true;
		S.AutoExposureMaxBrightness = ExposureEV;
		S.bOverride_AutoExposureBias = true;
		S.AutoExposureBias = 0.f;
		S.bOverride_BloomIntensity = true;
		S.BloomIntensity = BloomIntensity;
		S.bOverride_BloomThreshold = true;
		S.BloomThreshold = 0.6f;
		S.bOverride_VignetteIntensity = true;
		S.VignetteIntensity = 0.45f;
		S.bOverride_ColorSaturation = true;
		S.ColorSaturation = FVector4(1.1f, 1.1f, 1.1f, 1.f);
		S.bOverride_ColorContrast = true;
		S.ColorContrast = FVector4(1.1f, 1.1f, 1.1f, 1.f);
	}

	// ---- moon, stars, fireflies ----
	AAdvSky* Sky = W->SpawnActor<AAdvSky>(FVector::ZeroVector, FRotator::ZeroRotator);
	Sky->Setup(Assets);
	Fireflies = W->SpawnActor<AAdvFireflies>(FVector::ZeroVector, FRotator::ZeroRotator);
	Fireflies->Setup(Assets);
}

void AAdvGameMode::BuildForest()
{
	UWorld* W = GetWorld();
	AAdvLevelActor* Holder = W->SpawnActor<AAdvLevelActor>(FVector::ZeroVector, FRotator::ZeroRotator);
	USceneComponent* R = Holder->GetRootComponent();
	Spawned.Add(Holder);

	// dark ground far below
	Assets->Box(Holder, R, Assets->Lit(Holder, FLinearColor(0.05f, 0.1f, 0.08f), 1.f),
		G(0, -10, -60), FVector(50000.f, 50000.f, 10.f), FRotator::ZeroRotator, false);

	UInstancedStaticMeshComponent* Trunks = NewObject<UInstancedStaticMeshComponent>(Holder);
	Trunks->SetStaticMesh(Assets->Cylinder);
	Trunks->SetMobility(EComponentMobility::Movable);
	Trunks->SetMaterial(0, Assets->Lit(Holder, FLinearColor(0.17f, 0.12f, 0.1f)));
	Trunks->SetCastShadow(false);
	Trunks->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Trunks->SetupAttachment(R);
	Trunks->RegisterComponent();

	UInstancedStaticMeshComponent* Crowns[3];
	for (int32 v = 0; v < 3; ++v)
	{
		const float g = v * 0.5f;
		Crowns[v] = NewObject<UInstancedStaticMeshComponent>(Holder);
		Crowns[v]->SetStaticMesh(Assets->Cone);
		Crowns[v]->SetMobility(EComponentMobility::Movable);
		Crowns[v]->SetMaterial(0, Assets->Lit(Holder, FLinearColor(0.03f + 0.05f * g, 0.12f + 0.12f * g, 0.1f + 0.08f * g), 0.9f));
		Crowns[v]->SetCastShadow(false);
		Crowns[v]->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		Crowns[v]->SetupAttachment(R);
		Crowns[v]->RegisterComponent();
	}

	FRandomStream Rng(12345);
	for (int32 i = 0; i < 160; ++i)
	{
		const float Side = Rng.FRand() < 0.5f ? -1.f : 1.f;
		const float X = Side * Rng.FRandRange(7.5f, 38.f);
		const float Z = Rng.FRandRange(25.f, -150.f);
		const float H = Rng.FRandRange(11.f, 20.f);
		const float Th = H * 0.5f;
		const float Tw = 1.f + H * 0.02f;
		Trunks->AddInstance(FTransform(FQuat::Identity, G(X, -10.f + Th * 0.5f, Z), FVector(0.7f * Tw, 0.7f * Tw, Th)));
		const float Ch = H * 0.6f;
		const float Cr = 1.4f + H * 0.1f;
		const int32 Var = FMath::Clamp(FMath::FloorToInt(Rng.FRand() * 3.f), 0, 2);
		Crowns[Var]->AddInstance(FTransform(FQuat::Identity, G(X, -10.f + H * 0.4f + Ch * 0.5f, Z), FVector(Cr * 2.f, Cr * 2.f, Ch)));
	}
}

// ===================================================================== sounds (generated in code, like main.gd)
static void MakeTone(TArray<uint8>& Out, float Dur, float F0, float F1, float Vol, float Noise)
{
	const int32 Rate = 22050;
	const int32 N = FMath::RoundToInt(Rate * Dur);
	Out.SetNumUninitialized(N * 2);
	FRandomStream Rng(1);
	float Phase = 0.f;
	for (int32 i = 0; i < N; ++i)
	{
		const float K = (float)i / (float)N;
		const float F = FMath::Lerp(F0, F1, K);
		Phase += 2.f * PI * F / (float)Rate;
		const float Env = (1.f - K) * FMath::Min(1.f, K * 40.f);
		const float S = FMath::Sin(Phase) * (1.f - Noise) + (Rng.FRand() * 2.f - 1.f) * Noise;
		const int16 V = (int16)(FMath::Clamp(S * Env * Vol, -1.f, 1.f) * 32000.f);
		FMemory::Memcpy(&Out[i * 2], &V, 2);
	}
}

void AAdvGameMode::BuildSounds()
{
	const int32 N = (int32)EAdvSfx::Num;
	SfxData.SetNum(N);
	SfxDur.SetNum(N);
	auto Add = [this](EAdvSfx S, float F0, float F1, float Dur, float Vol, float Noise)
	{
		MakeTone(SfxData[(int32)S], Dur, F0, F1, Vol, Noise);
		SfxDur[(int32)S] = Dur;
	};
	Add(EAdvSfx::Jump, 300, 650, 0.16f, 0.5f, 0.f);
	Add(EAdvSfx::Spin, 500, 250, 0.22f, 0.35f, 0.25f);
	Add(EAdvSfx::Crate, 200, 80, 0.2f, 0.6f, 0.7f);
	Add(EAdvSfx::Stomp, 400, 150, 0.15f, 0.55f, 0.1f);
	Add(EAdvSfx::Hurt, 220, 70, 0.4f, 0.6f, 0.15f);
	Add(EAdvSfx::Check, 660, 990, 0.25f, 0.45f, 0.f);
	Add(EAdvSfx::Win, 500, 1200, 0.7f, 0.5f, 0.f);
	Add(EAdvSfx::Lose, 300, 60, 0.8f, 0.55f, 0.1f);
}

void AAdvGameMode::PlaySfx(EAdvSfx Sfx)
{
	const int32 I = (int32)Sfx;
	if (!SfxData.IsValidIndex(I)) { return; }

	USoundWaveProcedural* Wave = NewObject<USoundWaveProcedural>(this);
	Wave->SetSampleRate(22050);
	Wave->NumChannels = 1;
	Wave->Duration = SfxDur[I];
	Wave->SoundGroup = SOUNDGROUP_Default;
	Wave->bLooping = false;
	Wave->QueueAudio(SfxData[I].GetData(), SfxData[I].Num());

	SfxKeep.Add(Wave);
	if (SfxKeep.Num() > 16) { SfxKeep.RemoveAt(0); }

	UAudioComponent* AC = UGameplayStatics::SpawnSound2D(this, Wave, 0.9f);
	if (AC)
	{
		TWeakObjectPtr<UAudioComponent> Weak(AC);
		FTimerHandle H;
		GetWorldTimerManager().SetTimer(H, FTimerDelegate::CreateLambda([Weak]()
		{
			if (Weak.IsValid()) { Weak->Stop(); }
		}), SfxDur[I] + 0.25f, false);
	}
}

void AAdvGameMode::Burst(const FVector& Pos, const FLinearColor& Srgb, int32 Amount, float SpeedCm)
{
	if (!bFxOn) { return; }
	AAdvBurst* B = GetWorld()->SpawnActor<AAdvBurst>(Pos, FRotator::ZeroRotator);
	if (B) { B->Init(Assets, Srgb, Amount, SpeedCm); }
}

// ===================================================================== level (same layout as _build_level in main.gd)
void AAdvGameMode::Plat(float Cx, float Top, float Z0, float Z1, float W, const FLinearColor& Col)
{
	const float Ln = FMath::Abs(Z1 - Z0);
	Assets->Platform(Level, Level->GetRootComponent(), G(Cx, Top - 0.5f, (Z0 + Z1) * 0.5f), W, Ln, Top, Col);
}

void AAdvGameMode::SpawnCrate(float X, float Y, float Z)
{
	AAdvCrate* C = GetWorld()->SpawnActor<AAdvCrate>(G(X, Y, Z), FRotator::ZeroRotator);
	C->Setup(Assets, bUseImportedModels);
	Crates.Add(C);
	Spawned.Add(C);
}

void AAdvGameMode::SpawnEnemy(float X, float Y, float Z, float Range, bool bAxisX)
{
	AAdvEnemy* E = GetWorld()->SpawnActor<AAdvEnemy>(G(X, Y, Z), FRotator::ZeroRotator);
	E->Setup(Assets, bUseImportedModels);
	E->Center = G(X, Y, Z);
	E->Range = Range * 100.f;
	E->bAxisX = bAxisX;
	Enemies.Add(E);
	Spawned.Add(E);
}

void AAdvGameMode::SpawnTorch(float X, float Y, float Z)
{
	AAdvTorch* Tc = GetWorld()->SpawnActor<AAdvTorch>(G(X, Y, Z), FRotator::ZeroRotator);
	Tc->Setup(Assets);
	Spawned.Add(Tc);
}

void AAdvGameMode::SpawnCheckpoint(const FVector& Spot, const FVector& FlagPos)
{
	AAdvCheckpoint* C = GetWorld()->SpawnActor<AAdvCheckpoint>(G(FlagPos.X, FlagPos.Y, FlagPos.Z), FRotator::ZeroRotator);
	C->Setup(Assets);
	C->Spot = G(Spot.X, Spot.Y, Spot.Z);
	Checkpoints.Add(C);
	Spawned.Add(C);
}

void AAdvGameMode::SpawnHazard(const FVector& P)
{
	USceneComponent* R = Level->GetRootComponent();
	UMaterialInstanceDynamic* M = Assets->Glow(Level, FLinearColor(0.9f, 0.1f, 0.1f), 2.5f);
	HazardMats.Add(M);
	const FVector Pos = G(P.X, P.Y, P.Z);
	Assets->Box(Level, R, M, Pos, FVector(80.f, 300.f, 70.f), FRotator::ZeroRotator, false);
	Hazards.Add({ Pos, FVector(40.f, 150.f, 35.f) }); // half sizes in UE axes (X=depth, Y=width, Z=height)
	// red glow on the floor around the bar
	UMaterialInstanceDynamic* Warn = Assets->Glow(Level, FLinearColor(1.f, 0.15f, 0.1f), 0.8f);
	Assets->Box(Level, R, Warn, Pos + FVector(0.f, 0.f, -90.f), FVector(160.f, 280.f, 2.f), FRotator::ZeroRotator, false);
}

void AAdvGameMode::SpawnBridge(float Z0, float Z1, float Top, float Half)
{
	USceneComponent* R = Level->GetRootComponent();
	UMaterialInstanceDynamic* Wood = Assets->Lit(Level, FLinearColor(0.25f, 0.16f, 0.1f));
	const float Ln = FMath::Abs(Z1 - Z0);
	const float Zc = (Z0 + Z1) * 0.5f;
	const int32 N = FMath::Max(1, FMath::FloorToInt(Ln / 4.f));
	for (int32 s = -1; s <= 1; s += 2)
	{
		const float Rx = s * (Half + 0.1f);
		Assets->Box(Level, R, Wood, G(Rx, Top + 0.75f, Zc), FVector(Ln * 100.f, 8.f, 8.f), FRotator::ZeroRotator, false);
		Assets->Box(Level, R, Wood, G(Rx, Top + 0.4f, Zc), FVector(Ln * 100.f, 8.f, 8.f), FRotator::ZeroRotator, false);
		for (int32 i = 0; i <= N; ++i)
		{
			const float Pz = Z0 - i * (Ln / N);
			Assets->Box(Level, R, Wood, G(Rx, Top + 0.45f, Pz), FVector(16.f, 16.f, 90.f), FRotator::ZeroRotator, false);
		}
	}
}

void AAdvGameMode::SpawnArch(float Z, float Top, float Half)
{
	USceneComponent* R = Level->GetRootComponent();
	UMaterialInstanceDynamic* Stone = Assets->Lit(Level, FLinearColor(0.4f, 0.4f, 0.45f));
	Assets->Box(Level, R, Stone, G(-Half, Top + 1.7f, Z), FVector(35.f, 35.f, 340.f));
	Assets->Box(Level, R, Stone, G(Half, Top + 1.7f, Z), FVector(35.f, 35.f, 340.f));
	Assets->Box(Level, R, Stone, G(0, Top + 3.5f, Z), FVector(50.f, (Half * 2.f + 0.7f) * 100.f, 40.f));
}

void AAdvGameMode::SpawnGoal()
{
	USceneComponent* R = Level->GetRootComponent();
	// glowing light beam
	UMaterialInstanceDynamic* Beam = Assets->Glow(Level, FLinearColor(1.f, 0.85f, 0.4f), 3.f);
	Assets->Box(Level, R, Beam, G(0, 12, -115), FVector(30.f, 30.f, 1600.f), FRotator::ZeroRotator, false);

	// goal flag (your model if imported, otherwise pole + banner)
	const FVector FlagPos = G(2.f, 4.f, -116.f);
	AActor* Holder = Level;
	if (!(bUseImportedModels && Assets->ImportedModel(Holder, R, TEXT("Flag"), 260.f, FlagPos + FVector(0, 0, 130.f))))
	{
		UMaterialInstanceDynamic* Pole = Assets->Lit(Level, FLinearColor(0.7f, 0.7f, 0.75f), 0.3f);
		UMaterialInstanceDynamic* Banner = Assets->Glow(Level, FLinearColor(1.f, 0.8f, 0.2f), 1.6f);
		Assets->Box(Level, R, Pole, FlagPos + FVector(0, 0, 150.f), FVector(12.f, 12.f, 300.f));
		Assets->Box(Level, R, Banner, FlagPos + FVector(0, 55.f, 250.f), FVector(6.f, 100.f, 60.f), FRotator::ZeroRotator, false);
	}

	UPointLightComponent* L = NewObject<UPointLightComponent>(Level);
	L->SetMobility(EComponentMobility::Movable);
	L->SetIntensityUnits(ELightUnits::Candelas);
	L->SetIntensity(1.8f * PI * Assets->ExposureComp * 25.f);
	L->SetAttenuationRadius(1400.f);
	L->SetLightColor(ToLin(FLinearColor(1.f, 0.85f, 0.45f)), true);
	L->SetCastShadows(false);
	L->SetRelativeLocation(G(0, 6.5, -115));
	L->SetupAttachment(R);
	L->RegisterComponent();
}

void AAdvGameMode::BuildLevel()
{
	UWorld* W = GetWorld();
	Level = W->SpawnActor<AAdvLevelActor>(FVector::ZeroVector, FRotator::ZeroRotator);
	Spawned.Add(Level);

	const FLinearColor Green(0.2f, 0.36f, 0.27f);
	const FLinearColor Brown(0.36f, 0.32f, 0.3f);
	const FLinearColor Wood(0.3f, 0.21f, 0.15f);
	const FLinearColor Red(0.5f, 0.17f, 0.2f);
	const FLinearColor Gold(0.95f, 0.72f, 0.2f);

	// start area
	Plat(0, 0.f, 8, -12, 8, Green);
	SpawnCrate(-2, 0.5f, -3); SpawnCrate(0, 0.5f, -3); SpawnCrate(2, 0.5f, -3);
	SpawnEnemy(0, 0.4f, -7, 3.f, true);
	SpawnTorch(-3.6f, 0.f, 0.f); SpawnTorch(3.6f, 0.f, 0.f);

	// stairs
	Plat(0, 0.f, -15, -18, 3.5f, Brown);
	Plat(0, 0.8f, -21, -24, 3.5f, Brown);
	Plat(0, 1.6f, -27, -30, 3.5f, Red);
	SpawnCrate(0, 1.3f, -22.5f);
	SpawnCrate(0, 2.1f, -28.5f);
	SpawnTorch(-1.5f, 1.6f, -28.f);

	// wooden bridge
	Plat(0, 1.6f, -30, -46, 1.6f, Wood);
	SpawnBridge(-30.f, -46.f, 1.6f, 0.8f);
	SpawnCheckpoint(FVector(0, 2.1f, -31), FVector(0.55f, 2.6f, -31));
	SpawnEnemy(0, 2.0f, -38, 4.f, false);

	// meadow 2
	Plat(0, 1.6f, -46, -54, 8, Green);
	SpawnCrate(-2, 2.1f, -49); SpawnCrate(2, 2.1f, -49); SpawnCrate(0, 2.1f, -52);
	SpawnCheckpoint(FVector(0, 2.1f, -50), FVector(3, 2.6f, -50));
	SpawnEnemy(0, 2.0f, -48, 3.f, true);
	SpawnTorch(-3.6f, 1.6f, -51.f); SpawnTorch(3.6f, 1.6f, -51.f);

	// moving platform
	{
		const float Top = 1.6f, Z0 = -56.5f, Z1 = -59.5f, Wd = 3.5f;
		AAdvMover* M = W->SpawnActor<AAdvMover>(G(0, Top - 0.5f, (Z0 + Z1) * 0.5f), FRotator::ZeroRotator);
		M->Setup(Assets, Wd, FMath::Abs(Z1 - Z0), Top, FLinearColor(0.2f, 0.35f, 0.6f));
		M->Base = M->GetActorLocation();
		M->Amp = 200.f;
		Movers.Add(M);
		Spawned.Add(M);
	}

	// meadow 3
	Plat(0, 1.6f, -66, -72, 8, Green);
	SpawnCrate(-2, 2.1f, -70); SpawnCrate(2, 2.1f, -70);
	SpawnCheckpoint(FVector(0, 2.1f, -68), FVector(3, 2.6f, -68));
	SpawnEnemy(0, 2.0f, -69, 3.f, true);
	SpawnTorch(-3.6f, 1.6f, -67.f);

	// laser corridor
	Plat(0, 1.6f, -72, -90, 3, Brown);
	SpawnArch(-75.f, 1.6f, 1.75f); SpawnArch(-79.f, 1.6f, 1.75f);
	SpawnArch(-83.f, 1.6f, 1.75f); SpawnArch(-87.f, 1.6f, 1.75f);
	SpawnHazard(FVector(0, 1.95f, -76)); SpawnHazard(FVector(0, 1.95f, -81)); SpawnHazard(FVector(0, 1.95f, -86));
	SpawnTorch(-1.4f, 1.6f, -73.f); SpawnTorch(1.4f, 1.6f, -89.f);

	// climb
	Plat(0, 2.4f, -93, -96, 3, Brown);
	Plat(0, 3.2f, -99, -102, 3, Brown);
	SpawnCheckpoint(FVector(0, 3.7f, -100.5f), FVector(1.f, 4.2f, -100.5f));
	SpawnTorch(-1.3f, 3.2f, -99.6f);
	Plat(0, 4.f, -105, -108, 3, Brown);
	Plat(0, 4.f, -111, -119, 8, Gold);

	// goal
	SpawnTorch(-3.6f, 4.f, -113.f); SpawnTorch(3.6f, 4.f, -113.f);
	SpawnGoal();
}

void AAdvGameMode::ResetGame()
{
	for (AActor* A : Spawned) { if (IsValid(A)) { A->Destroy(); } }
	Spawned.Empty(); Crates.Empty(); Enemies.Empty(); Checkpoints.Empty(); Movers.Empty();
	HazardMats.Empty(); Hazards.Empty();

	Fruits = 0; Lives = 3; T = 0.f; bWon = false;
	RespawnPos = StartPos;
	BuildForest();
	BuildLevel();

	if (Player)
	{
		Player->bWin = false;
		Player->TeleportToStart(StartPos);
		Player->SetPlaying(true);
	}
	State = EAdvState::Play;
}

// ===================================================================== UI actions
void AAdvGameMode::ShowPanel(const FString& Title, const FString& Button)
{
	PanelTitle = Title;
	PanelButton = Button;
}

void AAdvGameMode::OnMainButton()
{
	if (State == EAdvState::Menu || State == EAdvState::Pause)
	{
		State = EAdvState::Play;
		if (Player) { Player->SetPlaying(true); }
	}
	else
	{
		ResetGame(); // retry / play again
	}
}

void AAdvGameMode::OnPause()
{
	if (State != EAdvState::Play) { return; }
	State = EAdvState::Pause;
	if (Player) { Player->SetPlaying(false); }
	ShowPanel(TEXT("PAUSED"), TEXT("RESUME"));
}

void AAdvGameMode::OnQuality()
{
	bFxOn = !bFxOn;
	if (Sun) { Sun->GetLightComponent()->SetCastShadows(bFxOn); }
	if (Fireflies) { Fireflies->SetActorHiddenInGame(!bFxOn); }
	if (Post)
	{
		Post->Settings.BloomIntensity = bFxOn ? BloomIntensity : 0.f;
		Post->Settings.VignetteIntensity = bFxOn ? 0.45f : 0.f;
	}
}

bool AAdvGameMode::Near(const FVector& A, const FVector& B, float R) const
{
	return FVector2D(A.X - B.X, A.Y - B.Y).Size() < R && FMath::Abs(A.Z - B.Z) < 160.f;
}

void AAdvGameMode::Hurt()
{
	Lives -= 1;
	HurtFlash = 1.f;
	if (Player) { Player->Shake(0.3f, 14.f); }
	if (Lives <= 0)
	{
		State = EAdvState::Over;
		PlaySfx(EAdvSfx::Lose);
		ShowPanel(TEXT("GAME OVER"), TEXT("RETRY"));
		if (Player) { Player->SetPlaying(false); }
		return;
	}
	PlaySfx(EAdvSfx::Hurt);
	if (Player)
	{
		Burst(Player->GetActorLocation(), FLinearColor(1.f, 0.3f, 0.3f), 12, 400.f);
		Player->TeleportToStart(RespawnPos);
	}
}

// ===================================================================== main loop (port of _physics_process)
void AAdvGameMode::Tick(float Dt)
{
	Super::Tick(Dt);
	if (!Player) { Player = Cast<AAdvCharacter>(UGameplayStatics::GetPlayerPawn(this, 0)); }
	if (!Player) { return; }

	HurtFlash = FMath::Max(0.f, HurtFlash - Dt * 2.5f);

	// hazards pulse even in menus
	const float Pulse = 2.5f * (0.75f + 0.25f * FMath::Sin(GetWorld()->GetTimeSeconds() * 6.f));
	for (UMaterialInstanceDynamic* M : HazardMats)
	{
		if (M) { Assets->SetGlow(M, FLinearColor(0.9f, 0.1f, 0.1f), Pulse); }
	}

	if (State != EAdvState::Play) { return; }
	T += Dt;

	const FVector PL = Player->GetActorLocation();

	// ---- spin attack ----
	if (Player->SpinT > 0.f)
	{
		SpinSparkT -= Dt;
		if (SpinSparkT <= 0.f)
		{
			SpinSparkT = 0.07f;
			Burst(PL, FLinearColor(0.4f, 0.7f, 1.f), 3, 350.f);
		}
		for (int32 i = Crates.Num() - 1; i >= 0; --i)
		{
			AAdvCrate* C = Crates[i];
			if (IsValid(C) && Near(C->GetActorLocation(), PL, SpinRadius))
			{
				Burst(C->GetActorLocation(), FLinearColor(0.9f, 0.7f, 0.2f), 14, 500.f);
				Crates.RemoveAt(i);
				C->Destroy();
				Fruits += 1;
				PlaySfx(EAdvSfx::Crate);
			}
		}
		for (int32 i = Enemies.Num() - 1; i >= 0; --i)
		{
			AAdvEnemy* E = Enemies[i];
			if (IsValid(E) && Near(E->GetActorLocation(), PL, SpinRadius))
			{
				Burst(E->GetActorLocation(), FLinearColor(0.45f, 0.12f, 0.55f), 12, 500.f);
				Enemies.RemoveAt(i);
				E->Destroy();
				PlaySfx(EAdvSfx::Stomp);
			}
		}
	}

	// ---- moving platforms (the character is carried by the engine's base-movement) ----
	for (AAdvMover* M : Movers)
	{
		if (IsValid(M)) { M->SetActorLocation(M->Base + FVector(-FMath::Sin(T * 1.2f) * M->Amp, 0.f, 0.f)); }
	}

	// ---- enemies ----
	for (int32 i = Enemies.Num() - 1; i >= 0; --i)
	{
		AAdvEnemy* E = Enemies[i];
		if (!IsValid(E)) { Enemies.RemoveAt(i); continue; }
		const float Off = FMath::Sin(T * 2.f) * E->Range;
		E->SetActorLocation(E->bAxisX ? E->Center + FVector(0.f, Off, 0.f) : E->Center + FVector(Off, 0.f, 0.f));

		if (FVector::Dist(PL, E->GetActorLocation()) < 100.f)
		{
			if (Player->GetVelocity().Z < 0.f && PL.Z > E->GetActorLocation().Z + 60.f)
			{
				Burst(E->GetActorLocation(), FLinearColor(0.45f, 0.12f, 0.55f), 12, 500.f);
				Enemies.RemoveAt(i);
				E->Destroy();
				Player->LaunchCharacter(FVector(0.f, 0.f, JumpV * 0.7f), false, true);
				PlaySfx(EAdvSfx::Stomp);
			}
			else
			{
				Hurt();
				if (State != EAdvState::Play) { return; }
			}
		}
	}

	// ---- laser bars ----
	for (const FHazard& H : Hazards)
	{
		if (FMath::Abs(PL.Y - H.Pos.Y) < H.Half.Y + 40.f && FMath::Abs(PL.X - H.Pos.X) < H.Half.X + 40.f && PL.Z - 80.f < H.Pos.Z + H.Half.Z)
		{
			Hurt();
			if (State != EAdvState::Play) { return; }
			break;
		}
	}

	// ---- checkpoints ----
	for (AAdvCheckpoint* Cp : Checkpoints)
	{
		if (IsValid(Cp) && !Cp->bDone && FVector::Dist(PL, Cp->Spot) < 200.f)
		{
			Cp->Activate();
			RespawnPos = Cp->Spot + FVector(0.f, 0.f, 30.f);
			PlaySfx(EAdvSfx::Check);
			Burst(Cp->Spot, FLinearColor(0.2f, 1.f, 0.2f), 16, 600.f);
		}
	}

	// ---- fell off the world ----
	if (PL.Z < -900.f)
	{
		Hurt();
		if (State != EAdvState::Play) { return; }
	}

	// ---- goal ----
	if (!bWon && PL.X > 11200.f && PL.Z > 300.f)
	{
		bWon = true;
		State = EAdvState::Win;
		PlaySfx(EAdvSfx::Win);
		Player->bWin = true;
		Burst(PL + FVector(0.f, 0.f, 100.f), FLinearColor(1.f, 0.84f, 0.f), 40, 800.f);
		ShowPanel(FString::Printf(TEXT("YOU WIN!\nFruits: %d"), Fruits), TEXT("PLAY AGAIN"));
		Player->SetPlaying(false);
	}
}
