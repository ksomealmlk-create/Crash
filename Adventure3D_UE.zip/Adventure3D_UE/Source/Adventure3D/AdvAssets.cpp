#include "AdvAssets.h"
#include "AdvCommon.h"
#include "Engine/StaticMesh.h"
#include "Engine/SkeletalMesh.h"
#include "Animation/AnimSequence.h"
#include "Materials/MaterialInterface.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/BoxComponent.h"
#include "GameFramework/Actor.h"
#include "UObject/ConstructorHelpers.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Modules/ModuleManager.h"

UAdvAssets::UAdvAssets()
{
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeF(TEXT("/Engine/BasicShapes/Cube.Cube"));
	static ConstructorHelpers::FObjectFinder<UStaticMesh> SphereF(TEXT("/Engine/BasicShapes/Sphere.Sphere"));
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CylF(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
	static ConstructorHelpers::FObjectFinder<UStaticMesh> ConeF(TEXT("/Engine/BasicShapes/Cone.Cone"));
	static ConstructorHelpers::FObjectFinder<UMaterialInterface> BasicF(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
	static ConstructorHelpers::FObjectFinderOptional<UMaterialInterface> LitF(TEXT("/Game/Materials/M_Adv_Lit.M_Adv_Lit"));
	static ConstructorHelpers::FObjectFinderOptional<UMaterialInterface> GlowF(TEXT("/Game/Materials/M_Adv_Glow.M_Adv_Glow"));
	static ConstructorHelpers::FObjectFinderOptional<UMaterialInterface> VcF(TEXT("/Game/Materials/M_Adv_VertexColor.M_Adv_VertexColor"));
	static ConstructorHelpers::FObjectFinderOptional<UMaterialInterface> EmissF(TEXT("/Engine/EngineMaterials/EmissiveMeshMaterial.EmissiveMeshMaterial"));

	Cube = CubeF.Object;
	Sphere = SphereF.Object;
	Cylinder = CylF.Object;
	Cone = ConeF.Object;

	bCustomLit = LitF.Succeeded();
	LitBase = bCustomLit ? LitF.Get() : BasicF.Object;

	bCustomGlow = GlowF.Succeeded();
	if (bCustomGlow) { GlowBase = GlowF.Get(); }
	else if (EmissF.Succeeded()) { GlowBase = EmissF.Get(); }
	else { GlowBase = BasicF.Object; }

	if (VcF.Succeeded()) { VertexColorBase = VcF.Get(); }
}

UMaterialInstanceDynamic* UAdvAssets::Lit(UObject* Outer, const FLinearColor& Srgb, float Roughness) const
{
	UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(LitBase, Outer);
	M->SetVectorParameterValue(TEXT("Color"), Adv::ToLin(Srgb));
	M->SetScalarParameterValue(TEXT("Roughness"), Roughness);
	if (bCustomLit)
	{
		// Moonlit ambient term baked into the material (Godot: ambient (0.32,0.4,0.65) x 0.55).
		const FLinearColor Amb = Adv::ToLin(FLinearColor(0.32f, 0.4f, 0.65f)) * 0.55f;
		M->SetVectorParameterValue(TEXT("AmbientTint"), Amb);
		M->SetScalarParameterValue(TEXT("AmbientBoost"), ExposureComp);
	}
	return M;
}

void UAdvAssets::SetGlow(UMaterialInstanceDynamic* M, const FLinearColor& Srgb, float Energy) const
{
	const FLinearColor C = Adv::ToLin(Srgb);
	if (bCustomGlow)
	{
		M->SetVectorParameterValue(TEXT("Color"), C);
		M->SetScalarParameterValue(TEXT("Intensity"), Energy * ExposureComp);
	}
	else
	{
		const FLinearColor H = C * (Energy * ExposureComp);
		M->SetVectorParameterValue(TEXT("Color"), H);
		M->SetVectorParameterValue(TEXT("EmissiveColor"), H);
		M->SetVectorParameterValue(TEXT("BaseColor"), H);
	}
}

UMaterialInstanceDynamic* UAdvAssets::Glow(UObject* Outer, const FLinearColor& Srgb, float Energy) const
{
	UMaterialInstanceDynamic* M = UMaterialInstanceDynamic::Create(GlowBase, Outer);
	SetGlow(M, Srgb, Energy);
	return M;
}

USceneComponent* UAdvAssets::Pivot(AActor* Owner, USceneComponent* Parent, const FVector& Loc) const
{
	USceneComponent* P = NewObject<USceneComponent>(Owner);
	P->SetMobility(EComponentMobility::Movable);
	P->SetRelativeLocation(Loc);
	if (Parent) { P->SetupAttachment(Parent); } else { Owner->SetRootComponent(P); }
	P->RegisterComponent();
	return P;
}

UStaticMeshComponent* UAdvAssets::Part(AActor* Owner, USceneComponent* Parent, UStaticMesh* Mesh, UMaterialInterface* Mat,
	const FVector& Loc, const FVector& Scale, const FRotator& Rot, bool bShadow) const
{
	UStaticMeshComponent* C = NewObject<UStaticMeshComponent>(Owner);
	C->SetStaticMesh(Mesh);
	C->SetMobility(EComponentMobility::Movable);
	C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	C->SetCastShadow(bShadow);
	if (Mat) { C->SetMaterial(0, Mat); }
	C->SetRelativeLocation(Loc);
	C->SetRelativeRotation(Rot);
	C->SetRelativeScale3D(Scale);
	if (Parent) { C->SetupAttachment(Parent); } else { Owner->SetRootComponent(C); }
	C->RegisterComponent();
	return C;
}

UBoxComponent* UAdvAssets::Collider(AActor* Owner, USceneComponent* Parent, const FVector& Loc, const FVector& FullSize) const
{
	UBoxComponent* B = NewObject<UBoxComponent>(Owner);
	B->SetMobility(EComponentMobility::Movable);
	B->SetBoxExtent(FullSize * 0.5);
	B->SetCollisionProfileName(TEXT("BlockAll"));
	B->SetCanEverAffectNavigation(false);
	B->SetHiddenInGame(true);
	B->SetRelativeLocation(Loc);
	if (Parent) { B->SetupAttachment(Parent); } else { Owner->SetRootComponent(B); }
	B->RegisterComponent();
	return B;
}

UStaticMeshComponent* UAdvAssets::Box(AActor* Owner, USceneComponent* Parent, UMaterialInterface* Mat, const FVector& Loc,
	const FVector& SizeCm, const FRotator& Rot, bool bShadow) const
{
	return Part(Owner, Parent, Cube, Mat, Loc, SizeCm / 100.0, Rot, bShadow);
}

UStaticMeshComponent* UAdvAssets::Ball(AActor* Owner, USceneComponent* Parent, UMaterialInterface* Mat, const FVector& Loc,
	float RadiusCm, const FVector& Squash, bool bShadow) const
{
	return Part(Owner, Parent, Sphere, Mat, Loc, Squash * (RadiusCm / 50.0), FRotator::ZeroRotator, bShadow);
}

UStaticMeshComponent* UAdvAssets::Tube(AActor* Owner, USceneComponent* Parent, UMaterialInterface* Mat, const FVector& Loc,
	float RadiusCm, float LengthCm, const FRotator& Rot, bool bShadow) const
{
	return Part(Owner, Parent, Cylinder, Mat, Loc, FVector(RadiusCm / 50.0, RadiusCm / 50.0, LengthCm / 100.0), Rot, bShadow);
}

UStaticMeshComponent* UAdvAssets::Spike(AActor* Owner, USceneComponent* Parent, UMaterialInterface* Mat, const FVector& Loc,
	float RadiusCm, float HeightCm, const FRotator& Rot, bool bShadow) const
{
	return Part(Owner, Parent, Cone, Mat, Loc, FVector(RadiusCm / 50.0, RadiusCm / 50.0, HeightCm / 100.0), Rot, bShadow);
}

void UAdvAssets::Platform(AActor* O, USceneComponent* P, const FVector& C, float W, float Ln, float Top,
	const FLinearColor& Srgb) const
{
	UMaterialInstanceDynamic* Main = Lit(O, Srgb);
	UMaterialInstanceDynamic* TopM = Lit(O, Adv::Lighten(Srgb, 0.3f));
	UMaterialInstanceDynamic* BotM = Lit(O, Adv::Darken(Srgb, 0.3f));
	UMaterialInstanceDynamic* PilM = Lit(O, FLinearColor(0.3f, 0.25f, 0.22f));

	const FVector Size(Ln * 100.f, W * 100.f, 100.f);
	Collider(O, P, C, Size);
	Box(O, P, Main, C, Size);
	Box(O, P, TopM, C + FVector(0, 0, 46), FVector((Ln + 0.06f) * 100.f, (W + 0.06f) * 100.f, 10.f), FRotator::ZeroRotator, false);
	Box(O, P, BotM, C + FVector(0, 0, -40), FVector((Ln + 0.04f) * 100.f, (W + 0.04f) * 100.f, 22.f), FRotator::ZeroRotator, false);

	// stone pillars going down into the dark
	const float H = Top + 9.f;
	const int32 N = FMath::Max(1, FMath::FloorToInt(Ln / 10.f));
	const float Pw = FMath::Min(W * 0.4f, 1.2f);
	for (int32 i = 0; i < N; ++i)
	{
		float Z = 0.f;
		if (N > 1) { Z = FMath::Lerp(-Ln * 0.5f + 1.f, Ln * 0.5f - 1.f, (float)i / (float)(N - 1)); }
		Box(O, P, PilM, C + FVector(-Z * 100.f, 0.f, (-0.5f - H * 0.5f) * 100.f), FVector(Pw * 100.f, Pw * 100.f, H * 100.f), FRotator::ZeroRotator, false);
	}

	// glowing edge strips (extra polish)
	UMaterialInstanceDynamic* Edge = Glow(O, Adv::Lighten(Srgb, 0.55f), 1.6f);
	for (int32 s = -1; s <= 1; s += 2)
	{
		Box(O, P, Edge, C + FVector(0.f, s * (W * 50.f + 2.f), 48.f), FVector(Ln * 100.f, 5.f, 5.f), FRotator::ZeroRotator, false);
	}
}

UObject* UAdvAssets::FindImported(const FString& Folder, UClass* Class)
{
	FAssetRegistryModule& Mod = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	TArray<FAssetData> Found;
	Mod.Get().GetAssetsByPath(FName(*(FString(TEXT("/Game/Models/")) + Folder)), Found, true);
	for (const FAssetData& A : Found)
	{
		if (A.AssetClassPath == Class->GetClassPathName())
		{
			return A.GetAsset();
		}
	}
	return nullptr;
}

USceneComponent* UAdvAssets::ImportedModel(AActor* Owner, USceneComponent* Parent, const FString& Folder, float TargetCm,
	const FVector& Loc, UMaterialInterface* MatOverride) const
{
	if (UStaticMesh* SM = Cast<UStaticMesh>(FindImported(Folder, UStaticMesh::StaticClass())))
	{
		const FBoxSphereBounds B = SM->GetBounds();
		const float Max = FMath::Max3(B.BoxExtent.X, B.BoxExtent.Y, B.BoxExtent.Z) * 2.f;
		if (Max < 1.f) { return nullptr; }
		UStaticMeshComponent* C = Part(Owner, Parent, SM, nullptr, Loc, FVector(TargetCm / Max));
		if (MatOverride)
		{
			for (int32 i = 0; i < C->GetNumMaterials(); ++i) { C->SetMaterial(i, MatOverride); }
		}
		return C;
	}
	if (USkeletalMesh* SK = Cast<USkeletalMesh>(FindImported(Folder, USkeletalMesh::StaticClass())))
	{
		const FBoxSphereBounds B = SK->GetBounds();
		const float Max = FMath::Max3(B.BoxExtent.X, B.BoxExtent.Y, B.BoxExtent.Z) * 2.f;
		if (Max < 1.f) { return nullptr; }
		USkeletalMeshComponent* C = NewObject<USkeletalMeshComponent>(Owner);
		C->SetMobility(EComponentMobility::Movable);
		C->SetSkeletalMeshAsset(SK);
		C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		C->SetRelativeLocation(Loc);
		C->SetRelativeScale3D(FVector(TargetCm / Max));
		if (MatOverride)
		{
			for (int32 i = 0; i < C->GetNumMaterials(); ++i) { C->SetMaterial(i, MatOverride); }
		}
		if (Parent) { C->SetupAttachment(Parent); } else { Owner->SetRootComponent(C); }
		C->RegisterComponent();
		if (UAnimSequence* Anim = Cast<UAnimSequence>(FindImported(Folder, UAnimSequence::StaticClass())))
		{
			C->SetAnimationMode(EAnimationMode::AnimationSingleNode);
			C->SetAnimation(Anim);
			C->Play(true);
		}
		return C;
	}
	return nullptr;
}
