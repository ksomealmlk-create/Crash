using UnrealBuildTool;
using System.Collections.Generic;

public class Adventure3DTarget : TargetRules
{
	public Adventure3DTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		DefaultBuildSettings = BuildSettingsVersion.Latest;
		IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
		ExtraModuleNames.Add("Adventure3D");
	}
}
